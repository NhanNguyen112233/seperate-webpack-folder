import * as i0 from '@angular/core';
import { Injectable, Component, Input, Directive, EventEmitter, ViewEncapsulation, Self, Optional, ViewChild, Output, HostListener, NgModule, inject, Inject } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import * as i1$1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i2$1 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i1$2 from '@angular/material/core';
import { NativeDateAdapter, MAT_DATE_FORMATS, DateAdapter, MatNativeDateModule } from '@angular/material/core';
import * as i4 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import * as i2$2 from '@angular/platform-browser';
import { Subject, BehaviorSubject } from 'rxjs';
import * as i1$3 from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as i1$4 from '@angular/material/snack-bar';
import { MAT_SNACK_BAR_DATA } from '@angular/material/snack-bar';
import * as i1$5 from '@angular/router';
import { RouterModule, NavigationEnd } from '@angular/router';

class AdminCoreWebLibsService {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class AdminCoreWebLibsComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: AdminCoreWebLibsComponent, isStandalone: true, selector: "lib-admin-core-web-libs", ngImport: i0, template: `
    <p>
      admin-core-web-libs works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-admin-core-web-libs', standalone: true, imports: [], template: `
    <p>
      admin-core-web-libs works!
    </p>
  ` }]
        }] });

const DEFAULT_INPUT_CONFIG = {
    width: '100%',
    height: '36px',
    innerWidth: '80%',
    innerHeight: '100%',
    minLength: 0,
    maxLength: 10000
};

class FormWrapperComponent {
    formGroupDirective;
    class = '';
    width = DEFAULT_INPUT_CONFIG.width;
    height = DEFAULT_INPUT_CONFIG.height;
    isDisabled = false;
    errorState = false;
    //we can create a service to handle error message
    errorMessage = 'Có lỗi xảy ra, vui lòng thử lại sau!';
    constructor(formGroupDirective) {
        this.formGroupDirective = formGroupDirective;
    }
    customClass() {
        if (this.class) {
            if (this.errorState) {
                return `form-field ${this.class} form-field-error`;
            }
            else {
                return `form-field ${this.class}`;
            }
        }
        if (this.errorState) {
            return 'form-field form-field-error';
        }
        else {
            return 'form-field';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: FormWrapperComponent, deps: [{ token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: FormWrapperComponent, isStandalone: true, selector: "admin-form-field", inputs: { class: "class", width: "width", height: "height", isDisabled: "isDisabled", errorState: "errorState", errorMessage: "errorMessage" }, providers: [FormGroupDirective], ngImport: i0, template: "<div  \r\n[ngStyle]=\"{'width': width, 'height': 'auto'}\"\r\n[ngClass]=\"customClass()\"\r\n>\r\n    <ng-content></ng-content>\r\n\r\n    <ng-container *ngIf=\"isDisabled\">\r\n        <div class=\"form-field-disabled\">\r\n        \r\n        </div>\r\n    </ng-container>\r\n</div>\r\n<ng-container *ngIf=\"errorState\">\r\n    <div class=\"form-field-error-text\">\r\n        {{errorMessage}}\r\n    </div>\r\n</ng-container>\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.form-field{display:inline-flex;position:relative;align-items:center;border:.0625rem solid var(--grey-2);border-radius:.25rem;min-width:6.25rem;min-height:2.25rem;box-sizing:border-box;padding:.5rem 1rem;overflow:hidden;background-color:var(--white-1)}.form-field-disabled{background-color:var(--grey-2);position:absolute;inset:0;opacity:.5;border-radius:.25rem;z-index:10}.form-field-error-text{color:var(--red-1);margin-top:.25rem;margin-bottom:.25rem;background:transparent;font-size:.75rem;line-height:1rem}.form-field-error{border-color:var(--red-1)}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: FormWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'admin-form-field', standalone: true, imports: [FormsModule, CommonModule], providers: [FormGroupDirective], template: "<div  \r\n[ngStyle]=\"{'width': width, 'height': 'auto'}\"\r\n[ngClass]=\"customClass()\"\r\n>\r\n    <ng-content></ng-content>\r\n\r\n    <ng-container *ngIf=\"isDisabled\">\r\n        <div class=\"form-field-disabled\">\r\n        \r\n        </div>\r\n    </ng-container>\r\n</div>\r\n<ng-container *ngIf=\"errorState\">\r\n    <div class=\"form-field-error-text\">\r\n        {{errorMessage}}\r\n    </div>\r\n</ng-container>\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.form-field{display:inline-flex;position:relative;align-items:center;border:.0625rem solid var(--grey-2);border-radius:.25rem;min-width:6.25rem;min-height:2.25rem;box-sizing:border-box;padding:.5rem 1rem;overflow:hidden;background-color:var(--white-1)}.form-field-disabled{background-color:var(--grey-2);position:absolute;inset:0;opacity:.5;border-radius:.25rem;z-index:10}.form-field-error-text{color:var(--red-1);margin-top:.25rem;margin-bottom:.25rem;background:transparent;font-size:.75rem;line-height:1rem}.form-field-error{border-color:var(--red-1)}\n"] }]
        }], ctorParameters: () => [{ type: i1.FormGroupDirective }], propDecorators: { class: [{
                type: Input
            }], width: [{
                type: Input
            }], height: [{
                type: Input
            }], isDisabled: [{
                type: Input
            }], errorState: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }] } });

class InputDirective {
    el;
    renderer;
    fullWidth = false;
    height = DEFAULT_INPUT_CONFIG.innerHeight;
    width = DEFAULT_INPUT_CONFIG.innerWidth;
    COMMON_CONFIG = {
        border: 'none',
        color: 'var(--purple-7)',
    };
    INPUT_REACT = {
        focus: {
            border: 'none',
            'user-select': 'none',
            outline: 'none',
        },
    };
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
    }
    ngAfterViewInit() {
        this.applyInitialStyles();
        this.applyEventListeners();
        this.applyPlaceholderStyle();
    }
    applyInitialStyles() {
        const nativeElement = this.el.nativeElement;
        this.renderer.setStyle(nativeElement, 'width', this.fullWidth ? '100%' : this.width);
        this.renderer.setStyle(nativeElement, 'height', this.height);
        for (const [property, value] of Object.entries(this.COMMON_CONFIG)) {
            this.renderer.setStyle(nativeElement, property, value);
        }
    }
    applyEventListeners() {
        const nativeElement = this.el.nativeElement;
        for (const [event, styles] of Object.entries(this.INPUT_REACT)) {
            this.renderer.listen(nativeElement, event, () => {
                for (const [property, value] of Object.entries(styles)) {
                    this.renderer.setStyle(nativeElement, property, value);
                }
            });
        }
    }
    applyPlaceholderStyle() {
        const nativeElement = this.el.nativeElement;
        // Create a style element
        const styleElement = this.renderer.createElement('style');
        this.renderer.setProperty(styleElement, 'innerHTML', `
      input[type=text][adminInput]::placeholder,[adminInput]::placeholder {
        color: var(--grey-2);
      }
    `);
        this.renderer.appendChild(document.head, styleElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: InputDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.9", type: InputDirective, isStandalone: true, selector: "input[type=text][adminInput],[adminInput]", inputs: { fullWidth: "fullWidth", height: "height", width: "width" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: InputDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[type=text][adminInput],[adminInput]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { fullWidth: [{
                type: Input
            }], height: [{
                type: Input
            }], width: [{
                type: Input
            }] } });

class CheckboxComponent {
    control;
    matCheckbox;
    indeterminate = false;
    disabled = false;
    value = false;
    changeEvent = new EventEmitter();
    constructor(control) {
        this.control = control;
        if (this.control) {
            this.control.valueAccessor = this;
        }
    }
    onChangeFn = (_) => { };
    onTouchedFn = () => { };
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    writeValue(obj) {
        this.value = obj;
    }
    onChange($event) {
        this.changeEvent.emit($event);
        this.onChangeFn(this.value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CheckboxComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: CheckboxComponent, isStandalone: true, selector: "tpb-checkbox", inputs: { indeterminate: "indeterminate", disabled: "disabled", value: "value" }, outputs: { changeEvent: "changeEvent" }, viewQueries: [{ propertyName: "matCheckbox", first: true, predicate: ["matCheckbox"], descendants: true, static: true }], ngImport: i0, template: "<mat-checkbox\r\n  class=\"tpb-checkbox\"\r\n  #matCheckbox\r\n  [disabled]=\"disabled\"\r\n  [(ngModel)]=\"value\"\r\n  (ngModelChange)=\"onChange($event)\"\r\n  [indeterminate]=\"indeterminate\"\r\n>\r\n<ng-content></ng-content>\r\n</mat-checkbox>\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}::ng-deep .mdc-checkbox__native-control:enabled:checked~.mdc-checkbox__background,.mdc-checkbox__native-control:enabled:indeterminate~.mdc-checkbox__background{border-color:transparent!important;background-color:var(--orange-1)!important}::ng-deep .mdc-checkbox__background{border:.125rem solid var(--orange-1)!important;width:.8125rem!important;height:.8125rem!important}::ng-deep .mdc-checkbox--disabled .mdc-checkbox__background{border:.125rem solid var(--grey-6)!important}::ng-deep .mdc-checkbox{width:.8125rem!important;height:.8125rem!important;padding:calc((var(--mdc-checkbox-state-layer-size, 40px) - 18px) / 2)!important;flex:auto!important}::ng-deep .mdc-checkbox__native-control:enabled:checked~.mdc-checkbox__background,::ng-deep .mdc-checkbox__native-control:enabled:indeterminate~.mdc-checkbox__background{border-color:transparent!important;background-color:var(--orange-1)!important}::ng-deep .mat-mdc-checkbox-touch-target{width:.9375rem!important;height:.9375rem!important}\n"], dependencies: [{ kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2$1.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: "tpb-checkbox", standalone: true, imports: [MatCheckboxModule, FormsModule], encapsulation: ViewEncapsulation.Emulated, template: "<mat-checkbox\r\n  class=\"tpb-checkbox\"\r\n  #matCheckbox\r\n  [disabled]=\"disabled\"\r\n  [(ngModel)]=\"value\"\r\n  (ngModelChange)=\"onChange($event)\"\r\n  [indeterminate]=\"indeterminate\"\r\n>\r\n<ng-content></ng-content>\r\n</mat-checkbox>\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}::ng-deep .mdc-checkbox__native-control:enabled:checked~.mdc-checkbox__background,.mdc-checkbox__native-control:enabled:indeterminate~.mdc-checkbox__background{border-color:transparent!important;background-color:var(--orange-1)!important}::ng-deep .mdc-checkbox__background{border:.125rem solid var(--orange-1)!important;width:.8125rem!important;height:.8125rem!important}::ng-deep .mdc-checkbox--disabled .mdc-checkbox__background{border:.125rem solid var(--grey-6)!important}::ng-deep .mdc-checkbox{width:.8125rem!important;height:.8125rem!important;padding:calc((var(--mdc-checkbox-state-layer-size, 40px) - 18px) / 2)!important;flex:auto!important}::ng-deep .mdc-checkbox__native-control:enabled:checked~.mdc-checkbox__background,::ng-deep .mdc-checkbox__native-control:enabled:indeterminate~.mdc-checkbox__background{border-color:transparent!important;background-color:var(--orange-1)!important}::ng-deep .mat-mdc-checkbox-touch-target{width:.9375rem!important;height:.9375rem!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { matCheckbox: [{
                type: ViewChild,
                args: ["matCheckbox", { static: true }]
            }], indeterminate: [{
                type: Input
            }], disabled: [{
                type: Input
            }], value: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }] } });

class AdminElementService {
    renderer;
    constructor(rendererFactory) {
        this.renderer = rendererFactory.createRenderer(null, null);
    }
    rotate(element, degrees) {
        this.renderer.setStyle(element, 'transform', `rotate(${degrees}deg)`);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminElementService, deps: [{ token: i0.RendererFactory2 }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminElementService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminElementService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i0.RendererFactory2 }] });

class SelectComponent {
    adminElementService;
    elementRef;
    ngControl;
    isOpen = false;
    disabled = false;
    noReactiveFormState = {
        touched: false,
    };
    onChange = (value) => { };
    onTouched = () => {
        this.noReactiveFormState.touched = true;
    };
    onValidatorChange = () => { };
    placeholder = 'Tất cả';
    width = DEFAULT_INPUT_CONFIG.width;
    height = DEFAULT_INPUT_CONFIG.height;
    selectOptions = [];
    selectedValue = 1;
    onInputChange = new EventEmitter();
    icon;
    select;
    option;
    onClickOutside(event) {
        if (!(this.select && this.select.nativeElement.contains(event.target)) &&
            !(this.option && this.option.nativeElement.contains(event.target))) {
            if (this.isOpen) {
                this.onTouched();
            }
            this.isOpen = false;
            this.adminElementService.rotate(this.icon.nativeElement, 360);
        }
    }
    constructor(adminElementService, elementRef, ngControl) {
        this.adminElementService = adminElementService;
        this.elementRef = elementRef;
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    get valid() {
        return !!this.ngControl?.control?.valid;
    }
    get invalid() {
        return !!this.ngControl?.control?.invalid;
    }
    get dirty() {
        return !!this.ngControl?.control?.dirty;
    }
    get touched() {
        return this.ngControl
            ? !!this.ngControl?.control?.touched
            : this.noReactiveFormState.touched;
    }
    changeSelectState() {
        this.rotate();
    }
    isInputInvalid() {
        return this.invalid && this.touched;
    }
    showSelectedOption() {
        const foundedItem = this.selectOptions.find((i) => i.value === this.selectedValue);
        return foundedItem ? foundedItem.label : '';
    }
    handleSelect(item) {
        this.selectedValue = item.value;
        this.rotate();
        this.onChange(item.value);
        this.onInputChange.emit(item.value);
        this.onTouched();
    }
    writeValue(value) {
        // Implement your logic to write the value to the component
        this.selectedValue = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onFocus() { }
    onBlur() {
        this.onTouched();
    }
    rotate() {
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.adminElementService.rotate(this.icon.nativeElement, 180);
        }
        else {
            this.adminElementService.rotate(this.icon.nativeElement, 360);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: SelectComponent, deps: [{ token: AdminElementService }, { token: i0.ElementRef }, { token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: SelectComponent, isStandalone: true, selector: "tpb-select", inputs: { placeholder: "placeholder", width: "width", height: "height", selectOptions: "selectOptions", selectedValue: "selectedValue" }, outputs: { onInputChange: "onInputChange" }, host: { listeners: { "document:click": "onClickOutside($event)" } }, providers: [AdminElementService], viewQueries: [{ propertyName: "icon", first: true, predicate: ["icon"], descendants: true, static: true }, { propertyName: "select", first: true, predicate: ["select"], descendants: true }, { propertyName: "option", first: true, predicate: ["option"], descendants: true }], ngImport: i0, template: "\r\n<div class=\"admin-select\"\r\n    [ngStyle]=\"{'width': width}\"\r\n    #select    \r\n>\r\n    <div class=\"admin-select-container\" (click)=\"changeSelectState()\">\r\n        <admin-form-field\r\n            [isDisabled]=\"disabled\"\r\n            [errorState]=\"isInputInvalid()\"     \r\n        >\r\n            <div \r\n                adminInput\r\n                class=\"admin-select-input\"> \r\n                {{showSelectedOption()}}\r\n            </div>\r\n    \r\n            <div class=\"admin-select-icon\"   #icon>\r\n                <mat-icon  svgIcon=\"admin-arrow-down\"></mat-icon>\r\n            </div>      \r\n        </admin-form-field>\r\n    </div>\r\n\r\n    <ng-container *ngIf=\"isOpen\" #option>\r\n        <ul class=\"admin-select-option\"  >\r\n            <li *ngFor=\"let item of selectOptions\" (click)=\"handleSelect(item)\">\r\n            {{ item.label }}\r\n            </li>\r\n        </ul>\r\n    </ng-container>\r\n</div>\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.admin-select{position:relative;width:auto;height:auto}.admin-select:hover{cursor:pointer}.admin-select-container{position:relative}.admin-select-input{width:100%;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.admin-select-icon{position:absolute;top:.4375rem;right:1rem;width:1.375rem;height:1.375rem}.admin-select-icon:hover{cursor:pointer}.admin-select-option{position:absolute;top:2.5rem;left:0;right:0;max-height:12.5rem;overflow-x:hidden;overflow-y:auto;background-color:var(--white-1);z-index:3;box-shadow:0 .4375rem .75rem #0000001f;border-radius:.25rem}.admin-select-option::-webkit-scrollbar{width:.25rem}.admin-select-option::-webkit-scrollbar-track{background:transparent;border-radius:0 .25rem .25rem 0}.admin-select-option::-webkit-scrollbar-thumb{background-color:transparent;border-radius:.25rem;border:3px solid var(--grey-5)}.admin-select-option::-webkit-scrollbar-thumb:hover{background-color:transparent}.admin-select-option>li{padding:0 1rem;box-sizing:border-box;min-height:2.25rem;line-height:2.25rem}.admin-select-option>li:hover{background-color:var(--purple-2);cursor:pointer}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: FormWrapperComponent, selector: "admin-form-field", inputs: ["class", "width", "height", "isDisabled", "errorState", "errorMessage"] }, { kind: "directive", type: InputDirective, selector: "input[type=text][adminInput],[adminInput]", inputs: ["fullWidth", "height", "width"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: SelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tpb-select', standalone: true, imports: [
                        CommonModule,
                        CheckboxComponent,
                        FormsModule,
                        MatIconModule,
                        FormWrapperComponent,
                        InputDirective,
                    ], providers: [AdminElementService], template: "\r\n<div class=\"admin-select\"\r\n    [ngStyle]=\"{'width': width}\"\r\n    #select    \r\n>\r\n    <div class=\"admin-select-container\" (click)=\"changeSelectState()\">\r\n        <admin-form-field\r\n            [isDisabled]=\"disabled\"\r\n            [errorState]=\"isInputInvalid()\"     \r\n        >\r\n            <div \r\n                adminInput\r\n                class=\"admin-select-input\"> \r\n                {{showSelectedOption()}}\r\n            </div>\r\n    \r\n            <div class=\"admin-select-icon\"   #icon>\r\n                <mat-icon  svgIcon=\"admin-arrow-down\"></mat-icon>\r\n            </div>      \r\n        </admin-form-field>\r\n    </div>\r\n\r\n    <ng-container *ngIf=\"isOpen\" #option>\r\n        <ul class=\"admin-select-option\"  >\r\n            <li *ngFor=\"let item of selectOptions\" (click)=\"handleSelect(item)\">\r\n            {{ item.label }}\r\n            </li>\r\n        </ul>\r\n    </ng-container>\r\n</div>\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.admin-select{position:relative;width:auto;height:auto}.admin-select:hover{cursor:pointer}.admin-select-container{position:relative}.admin-select-input{width:100%;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.admin-select-icon{position:absolute;top:.4375rem;right:1rem;width:1.375rem;height:1.375rem}.admin-select-icon:hover{cursor:pointer}.admin-select-option{position:absolute;top:2.5rem;left:0;right:0;max-height:12.5rem;overflow-x:hidden;overflow-y:auto;background-color:var(--white-1);z-index:3;box-shadow:0 .4375rem .75rem #0000001f;border-radius:.25rem}.admin-select-option::-webkit-scrollbar{width:.25rem}.admin-select-option::-webkit-scrollbar-track{background:transparent;border-radius:0 .25rem .25rem 0}.admin-select-option::-webkit-scrollbar-thumb{background-color:transparent;border-radius:.25rem;border:3px solid var(--grey-5)}.admin-select-option::-webkit-scrollbar-thumb:hover{background-color:transparent}.admin-select-option>li{padding:0 1rem;box-sizing:border-box;min-height:2.25rem;line-height:2.25rem}.admin-select-option>li:hover{background-color:var(--purple-2);cursor:pointer}\n"] }]
        }], ctorParameters: () => [{ type: AdminElementService }, { type: i0.ElementRef }, { type: i1.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { placeholder: [{
                type: Input
            }], width: [{
                type: Input
            }], height: [{
                type: Input
            }], selectOptions: [{
                type: Input
            }], selectedValue: [{
                type: Input
            }], onInputChange: [{
                type: Output
            }], icon: [{
                type: ViewChild,
                args: ['icon', { static: true }]
            }], select: [{
                type: ViewChild,
                args: ['select']
            }], option: [{
                type: ViewChild,
                args: ['option']
            }], onClickOutside: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

const NOOP_VALUE_ACCESSOR = {
    writeValue() { },
    registerOnChange() { },
    registerOnTouched() { },
};
class InputComponent {
    ngControl;
    isDisabled = false;
    noReactiveFormState = {
        touched: false,
    };
    width = DEFAULT_INPUT_CONFIG.width;
    height = DEFAULT_INPUT_CONFIG.height;
    placeholder = '';
    customContent = '';
    value = '';
    minLength = DEFAULT_INPUT_CONFIG.minLength;
    maxLength = DEFAULT_INPUT_CONFIG.maxLength;
    required = false;
    errorMessage = '';
    type = 'text';
    onInputChange = new EventEmitter();
    onChange = (value) => { };
    onTouched = () => {
        this.noReactiveFormState.touched = true;
    };
    onValidatorChange = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    get valid() {
        return !!this.ngControl?.control?.valid;
    }
    get invalid() {
        return !!this.ngControl?.control?.invalid;
    }
    get dirty() {
        return !!this.ngControl?.control?.dirty;
    }
    get touched() {
        return this.ngControl
            ? !!this.ngControl?.control?.touched
            : this.noReactiveFormState.touched;
    }
    displayCustomContent(position) {
        return this.customContent === position || this.customContent === 'all';
    }
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    registerOnValidatorChange(fn) {
        this.onValidatorChange = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabled = isDisabled;
    }
    onFocus() { }
    onBlur() {
        this.onTouched();
    }
    isInputInvalid() {
        return ((this.invalid && this.touched) ||
            (this.dirty && this.invalid) ||
            (this.required && !this.value && this.touched));
    }
    onChangeValue(value) {
        this.value = value;
        this.onChange(value);
        this.onTouched();
        this.onValidatorChange();
        this.onInputChange.emit(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: InputComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: InputComponent, isStandalone: true, selector: "tpb-input", inputs: { width: "width", height: "height", placeholder: "placeholder", customContent: "customContent", value: "value", minLength: "minLength", maxLength: "maxLength", required: "required", errorMessage: "errorMessage", type: "type" }, outputs: { onInputChange: "onInputChange" }, ngImport: i0, template: "<admin-form-field\r\n[isDisabled]=\"isDisabled\"\r\n[errorState]=\"isInputInvalid()\"\r\n[errorMessage]=\"errorMessage\"\r\n>\r\n    <ng-container *ngIf=\"displayCustomContent('prefix')\">\r\n       <ng-content select=\"[prefix]\"></ng-content>\r\n       \r\n        <ng-template #prefix>\r\n            <!-- Default prefix content can go here if needed -->\r\n        </ng-template>\r\n    </ng-container>\r\n\r\n    <input \r\n        [(ngModel)]=\"value\"\r\n        (ngModelChange)=\"onChangeValue($event)\"\r\n        adminInput\r\n        [fullWidth]=\"true\"\r\n        [placeholder]=\"placeholder\"\r\n        [minLength]=\"minLength\"\r\n        [maxLength]=\"maxLength\"\r\n        [required]=\"required\"\r\n        (focus)=\"onFocus()\"\r\n        (blur)=\"onBlur()\"\r\n        [type]=\"type\"\r\n    />\r\n\r\n    <ng-container *ngIf=\"displayCustomContent('suffix')\">\r\n       <ng-content  select=\"[suffix]\"></ng-content>\r\n\r\n       <ng-template #suffix>\r\n        <!-- Default prefix content can go here if needed -->\r\n      </ng-template>\r\n    </ng-container>\r\n</admin-form-field>", styles: [""], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: FormWrapperComponent, selector: "admin-form-field", inputs: ["class", "width", "height", "isDisabled", "errorState", "errorMessage"] }, { kind: "directive", type: InputDirective, selector: "input[type=text][adminInput],[adminInput]", inputs: ["fullWidth", "height", "width"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: InputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tpb-input', standalone: true, imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        FormsModule,
                        FormWrapperComponent,
                        InputDirective,
                    ], template: "<admin-form-field\r\n[isDisabled]=\"isDisabled\"\r\n[errorState]=\"isInputInvalid()\"\r\n[errorMessage]=\"errorMessage\"\r\n>\r\n    <ng-container *ngIf=\"displayCustomContent('prefix')\">\r\n       <ng-content select=\"[prefix]\"></ng-content>\r\n       \r\n        <ng-template #prefix>\r\n            <!-- Default prefix content can go here if needed -->\r\n        </ng-template>\r\n    </ng-container>\r\n\r\n    <input \r\n        [(ngModel)]=\"value\"\r\n        (ngModelChange)=\"onChangeValue($event)\"\r\n        adminInput\r\n        [fullWidth]=\"true\"\r\n        [placeholder]=\"placeholder\"\r\n        [minLength]=\"minLength\"\r\n        [maxLength]=\"maxLength\"\r\n        [required]=\"required\"\r\n        (focus)=\"onFocus()\"\r\n        (blur)=\"onBlur()\"\r\n        [type]=\"type\"\r\n    />\r\n\r\n    <ng-container *ngIf=\"displayCustomContent('suffix')\">\r\n       <ng-content  select=\"[suffix]\"></ng-content>\r\n\r\n       <ng-template #suffix>\r\n        <!-- Default prefix content can go here if needed -->\r\n      </ng-template>\r\n    </ng-container>\r\n</admin-form-field>" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { width: [{
                type: Input
            }], height: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], customContent: [{
                type: Input
            }], value: [{
                type: Input
            }], minLength: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], required: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], type: [{
                type: Input
            }], onInputChange: [{
                type: Output
            }] } });

class CustomDateAdapter extends NativeDateAdapter {
    // Implement required methods for your custom date adapter
    // For example:
    constructor() {
        super();
    }
    parse(value) {
        if (typeof value === 'string' && value.indexOf('/') > -1) {
            const str = value.split('/');
            if (str.length < 2 ||
                isNaN(+str[0]) ||
                isNaN(+str[1]) ||
                isNaN(+str[2])) {
                return null;
            }
            return new Date(Number(str[2]), Number(str[1]) - 1, Number(str[0]));
        }
        const timestamp = typeof value === 'number' ? value : Date.parse(value);
        return isNaN(timestamp) ? null : new Date(timestamp);
    }
    format(date, displayFormat) {
        let day = date.getDate().toString();
        day = +day < 10 ? '0' + day : day;
        let month = (date.getMonth() + 1).toString();
        month = +month < 10 ? '0' + month : month;
        let year = date.getFullYear();
        return `${day}/${month}/${year}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CustomDateAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CustomDateAdapter });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CustomDateAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
const CUSTOM_DATE_FORMATS = {
    parse: {
        dateInput: 'input',
    },
    display: {
        dateInput: 'input',
        monthYearLabel: 'input',
        dateA11yLabel: 'input',
        monthYearA11yLabel: 'input',
    },
};

// import adminCalendar from '../assets/svg/calendar.svg';
const ICONS = {
    calendar: ` <svg width="16" height="16" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10.8887 2.00004V0.88893C10.8887 0.741587 10.8302 0.600279 10.726 0.496092C10.6218 0.391906 10.4805 0.333374 10.3331 0.333374C10.1858 0.333374 10.0445 0.391906 9.94031 0.496092C9.83612 0.600279 9.77759 0.741587 9.77759 0.88893V2.00004H10.8887Z" fill="#FF9800"/>
            <path d="M4.2222 2.00004V0.88893C4.2222 0.741587 4.16366 0.600279 4.05948 0.496092C3.95529 0.391906 3.81398 0.333374 3.66664 0.333374C3.5193 0.333374 3.37799 0.391906 3.2738 0.496092C3.16962 0.600279 3.11108 0.741587 3.11108 0.88893V2.00004H4.2222Z" fill="#FF9800"/>
            <path d="M11.9999 13.1111H1.99992C1.55789 13.1111 1.13397 12.9355 0.821407 12.6229C0.508847 12.3104 0.333252 11.8865 0.333252 11.4444L0.333252 4.22221C0.333252 3.78018 0.508847 3.35626 0.821407 3.0437C1.13397 2.73114 1.55789 2.55554 1.99992 2.55554H11.9999C12.4419 2.55554 12.8659 2.73114 13.1784 3.0437C13.491 3.35626 13.6666 3.78018 13.6666 4.22221V11.4444C13.6666 11.8865 13.491 12.3104 13.1784 12.6229C12.8659 12.9355 12.4419 13.1111 11.9999 13.1111ZM12.5555 5.33332H1.44436V11.4444C1.44436 11.5918 1.50289 11.7331 1.60708 11.8373C1.71127 11.9415 1.85258 12 1.99992 12H11.9999C12.1473 12 12.2886 11.9415 12.3928 11.8373C12.4969 11.7331 12.5555 11.5918 12.5555 11.4444V5.33332Z" fill="#FF9800"/>
            <path d="M2.55542 6.44446H4.77764V8.11112H2.55542V6.44446Z" fill="#FF9800"/>
            <path d="M5.88892 6.44446H8.11114V8.11112H5.88892V6.44446Z" fill="#FF9800"/>
            <path d="M2.55542 9.22229H4.77764V10.889H2.55542V9.22229Z" fill="#FF9800"/>
            <path d="M5.88892 9.22229H8.11114V10.889H5.88892V9.22229Z" fill="#FF9800"/>
            <path d="M9.22217 6.44446H11.4444V8.11112H9.22217V6.44446Z" fill="#FF9800"/>
        </svg>`,
    'arrow-down': `
    <svg  width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 13.75L5 8.78676L6.2963 7.5L10 11.1765L13.7037 7.5L15 8.78676L10 13.75Z" fill="#FF9800"/>
    </svg>
   `,
    search: `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.12492 13.2498C3.74747 13.2498 1 10.5024 1 7.12492C1 3.74747 3.74747 1 7.12492 1C10.5024 1 13.2498 3.74747 13.2498 7.12492C13.2498 10.5024 10.5024 13.2498 7.12492 13.2498ZM7.12492 2.74998C4.71258 2.74998 2.74998 4.71258 2.74998 7.12492C2.74998 9.53727 4.71258 11.4999 7.12492 11.4999C9.53727 11.4999 11.4999 9.53727 11.4999 7.12492C11.4999 4.71258 9.53727 2.74998 7.12492 2.74998Z" fill="#AD8AD8"/>
<path d="M14.7435 13.5062L12.6496 11.4124C12.2905 11.8748 11.8748 12.2904 11.4124 12.6496L13.5063 14.7435C13.5873 14.825 13.6837 14.8897 13.7899 14.9339C13.8961 14.978 14.0099 15.0007 14.1249 15.0007C14.2399 15.0007 14.3537 14.978 14.4599 14.9339C14.566 14.8897 14.6624 14.825 14.7435 14.7435C14.8248 14.6623 14.8893 14.5659 14.9334 14.4597C14.9774 14.3536 15 14.2398 15 14.1249C15 14.0099 14.9774 13.8961 14.9334 13.79C14.8893 13.6838 14.8248 13.5874 14.7435 13.5062Z" fill="#AD8AD8"/>
</svg>
`,
    tpb: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M18.2221 4.05297C18.2896 3.91625 18.3332 3.7539 18.3332 3.60009C18.3246 3.07885 17.888 2.66016 17.3505 2.66016H3.88379L7.54954 4.22387L14.3085 7.09494L17.9991 4.31786C18.0332 4.29223 18.076 4.25805 18.1016 4.22387C18.111 4.21534 18.111 4.21532 18.1195 4.20683L18.1195 4.20678C18.122 4.20341 18.1244 4.20004 18.1269 4.19667C18.1495 4.16578 18.1725 4.13421 18.1879 4.09569L18.2221 4.05297ZM8.06181 11.795L8.54887 15.7684L1.78133 4.05338C1.68733 3.88248 1.65315 3.68595 1.6711 3.48942C1.73091 3.01091 2.12312 2.66057 2.61018 2.66057C2.71272 2.66057 2.8238 2.6862 2.9178 2.72038L7.15605 4.52335L8.06181 11.795ZM17.5722 5.17269L10.7961 16.8963C10.6166 17.1697 10.327 17.3406 10.0023 17.3406C9.91767 17.3406 9.83307 17.3295 9.7519 17.3064C9.67072 17.2842 9.59296 17.25 9.52119 17.2056C9.44685 17.1594 9.37849 17.103 9.31953 17.039C9.28364 17.0005 9.24946 16.9603 9.21955 16.9168C9.18794 16.8732 9.16316 16.8253 9.14009 16.7766C9.10762 16.7108 9.08711 16.6459 9.07771 16.5733C9.06464 16.4854 9.05466 16.3976 9.04462 16.3093L9.04462 16.3093L9.03926 16.2622L9.02644 16.164C9.0243 16.1452 9.02195 16.1266 9.0196 16.108C9.01725 16.0894 9.0149 16.0708 9.01277 16.052C9.00849 16.011 9.00337 15.97 8.99824 15.929C8.99525 15.9063 8.99247 15.8839 8.9897 15.8615C8.98692 15.839 8.98414 15.8166 8.98115 15.794C8.97816 15.7701 8.97539 15.7459 8.97261 15.7218L8.97261 15.7218C8.96983 15.6976 8.96705 15.6735 8.96406 15.6496C8.96044 15.6229 8.95706 15.5959 8.95367 15.5689C8.95065 15.5448 8.94762 15.5207 8.94441 15.4966C8.94142 15.4697 8.93821 15.443 8.93501 15.4163C8.9318 15.3896 8.9286 15.3629 8.92561 15.336C8.91792 15.2796 8.91109 15.224 8.90425 15.1685L8.90425 15.1685C8.89741 15.1104 8.89058 15.0531 8.88288 14.995C8.87947 14.9655 8.87584 14.9361 8.8722 14.9066C8.86857 14.8771 8.86494 14.8476 8.86152 14.8181C8.85469 14.7575 8.847 14.6968 8.83931 14.637L8.81709 14.4541L8.81709 14.4541L8.81708 14.4541C8.8094 14.3926 8.80171 14.3311 8.79487 14.2696L8.7718 14.085C8.76796 14.0547 8.76433 14.0241 8.76069 13.9936C8.75706 13.963 8.75343 13.9325 8.74959 13.9021L8.72651 13.721C8.71968 13.6612 8.71284 13.6022 8.70515 13.5424C8.70196 13.5157 8.69859 13.4888 8.6952 13.4618C8.69133 13.4309 8.68744 13.3999 8.68379 13.3689L8.66328 13.2006C8.65986 13.1737 8.65666 13.1468 8.65346 13.1198C8.65025 13.0929 8.64705 13.066 8.64363 13.0391C8.64044 13.0148 8.63743 12.9906 8.63444 12.9666C8.63102 12.9391 8.62762 12.9118 8.62398 12.8844C8.62099 12.8601 8.61821 12.8357 8.61543 12.8114C8.61265 12.787 8.60988 12.7627 8.60689 12.7383C8.6009 12.693 8.59492 12.6477 8.5898 12.6025L8.58486 12.5606L8.58485 12.5605C8.58163 12.5326 8.5784 12.5047 8.57442 12.4768C8.57228 12.458 8.56993 12.4393 8.56758 12.4205C8.56523 12.4017 8.56288 12.3829 8.56074 12.3641L8.54793 12.2632C8.54614 12.243 8.54353 12.2227 8.54095 12.2028L8.53767 12.1769C8.53639 12.165 8.5349 12.153 8.5334 12.1411L8.5334 12.141C8.5319 12.1291 8.53041 12.1171 8.52913 12.1051C8.52656 12.0872 8.524 12.0693 8.52229 12.0505C8.52058 12.0385 8.51887 12.0257 8.5146 11.9906L14.3678 7.58234L17.5722 5.17269Z" fill="#B284DC"/>
</svg>
`,
    fee: `
<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M4 4C3.46957 4 2.96086 4.21071 2.58579 4.58579C2.21071 4.96086 2 5.46957 2 6V10C2 10.5304 2.21071 11.0391 2.58579 11.4142C2.96086 11.7893 3.46957 12 4 12V6H14C14 5.46957 13.7893 4.96086 13.4142 4.58579C13.0391 4.21071 12.5304 4 12 4H4ZM6 10C6 9.46957 6.21071 8.96086 6.58579 8.58579C6.96086 8.21071 7.46957 8 8 8H16C16.5304 8 17.0391 8.21071 17.4142 8.58579C17.7893 8.96086 18 9.46957 18 10V14C18 14.5304 17.7893 15.0391 17.4142 15.4142C17.0391 15.7893 16.5304 16 16 16H8C7.46957 16 6.96086 15.7893 6.58579 15.4142C6.21071 15.0391 6 14.5304 6 14V10ZM12 14C12.5304 14 13.0391 13.7893 13.4142 13.4142C13.7893 13.0391 14 12.5304 14 12C14 11.4696 13.7893 10.9609 13.4142 10.5858C13.0391 10.2107 12.5304 10 12 10C11.4696 10 10.9609 10.2107 10.5858 10.5858C10.2107 10.9609 10 11.4696 10 12C10 12.5304 10.2107 13.0391 10.5858 13.4142C10.9609 13.7893 11.4696 14 12 14Z" fill="#B284DC"/>
</svg>
`,
    mark: `
<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17.9459 4.55365C17.4302 4.03729 16.5929 4.03762 16.0765 4.55365L7.66295 12.9675L3.92349 9.2281C3.40713 8.71174 2.57013 8.71174 2.05377 9.2281C1.53741 9.74446 1.53741 10.5815 2.05377 11.0978L6.7279 15.7719C6.98591 16.03 7.32424 16.1593 7.66259 16.1593C8.00095 16.1593 8.3396 16.0303 8.59761 15.7719L17.9459 6.42333C18.4623 5.90733 18.4623 5.06997 17.9459 4.55365Z" fill="#B284DC"/>
</svg>
`,
    config: `
<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M9.1665 6.6665L16.6665 6.6665" stroke="#B284DC" stroke-width="2" stroke-linecap="round"/>
<path d="M3.3335 13.3335L11.6668 13.3335" stroke="#B284DC" stroke-width="2" stroke-linecap="round"/>
<ellipse cx="5.8335" cy="6.6665" rx="2.5" ry="2.5" transform="rotate(90 5.8335 6.6665)" stroke="#B284DC" stroke-width="2" stroke-linecap="round"/>
<ellipse cx="14.1665" cy="13.3335" rx="2.5" ry="2.5" transform="rotate(90 14.1665 13.3335)" stroke="#B284DC" stroke-width="2" stroke-linecap="round"/>
</svg>
`,
    connect: `
<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.6983 8.30113C11.3326 7.93682 10.9076 7.63735 10.4415 7.41553C10.3011 7.55586 10.1899 7.72252 10.1141 7.90596C10.0383 8.08939 9.99947 8.28599 9.99984 8.48447C9.99984 8.64583 10.0301 8.79886 10.0771 8.94507C10.2733 9.06704 10.4597 9.20492 10.6271 9.37235C11.1991 9.94507 11.515 10.7057 11.515 11.5148C11.515 12.3239 11.1998 13.0852 10.6279 13.658L8.35514 15.9299C7.20969 17.0754 5.21423 17.0754 4.06953 15.9299C3.49681 15.3572 3.18166 14.5966 3.18166 13.7875C3.18166 12.9784 3.49681 12.2178 4.06878 11.6451L5.66272 10.0511C5.52561 9.54016 5.45558 9.01351 5.45438 8.48447C5.45438 8.36174 5.46423 8.23977 5.47181 8.11856C5.40438 8.17841 5.33544 8.23674 5.27029 8.30113L2.99756 10.5739C2.13923 11.4322 1.6665 12.5731 1.6665 13.7875C1.6665 15.0019 2.13923 16.1428 2.99756 17.0011C3.85666 17.8602 4.99756 18.333 6.21196 18.333C7.42635 18.333 8.56726 17.8602 9.42635 17.0011L11.6991 14.7292C12.5567 13.8701 13.0301 12.7292 13.0301 11.5148C13.0301 10.3004 12.5567 9.15947 11.6983 8.30113Z" fill="#B284DC"/>
<path d="M17.0023 2.99832C16.1432 2.13923 15.0023 1.6665 13.7879 1.6665C12.5735 1.6665 11.4326 2.13923 10.5735 2.99832L8.30079 5.27029C7.44321 6.12938 6.96973 7.27029 6.96973 8.48469C6.96973 9.69908 7.44245 10.84 8.30079 11.6983C8.66649 12.0626 9.09149 12.3621 9.55761 12.5839C9.84245 12.2983 10 11.918 10 11.515C10 11.3498 9.96897 11.193 9.91973 11.0438C9.72126 10.9278 9.53781 10.7879 9.37351 10.6271C8.80079 10.0544 8.48488 9.29378 8.48488 8.48469C8.48488 7.67559 8.80003 6.91423 9.372 6.3415L11.6447 4.06953C12.2175 3.49681 12.9788 3.18166 13.7879 3.18166C14.597 3.18166 15.3584 3.49681 15.9311 4.06953C16.5031 4.64226 16.8182 5.40287 16.8182 6.21196C16.8182 7.02105 16.5031 7.78166 15.9311 8.35438L14.3349 9.95059C14.4697 10.4551 14.5455 10.9786 14.5455 11.515C14.5455 11.6377 14.5364 11.7589 14.5296 11.8801C14.597 11.8203 14.6659 11.7627 14.7303 11.6983L17.0031 9.42559C17.8606 8.56726 18.3334 7.42635 18.3334 6.21196C18.3334 4.99756 17.8606 3.85666 17.0023 2.99832Z" fill="#B284DC"/>
</svg>
`,
    'customer-group': `
<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.75 17.5C8.75 17.5 7.5 17.5 7.5 16.25C7.5 15 8.75 11.25 13.75 11.25C18.75 11.25 20 15 20 16.25C20 17.5 18.75 17.5 18.75 17.5H8.75ZM13.75 10C14.7446 10 15.6984 9.60491 16.4017 8.90165C17.1049 8.19839 17.5 7.24456 17.5 6.25C17.5 5.25544 17.1049 4.30161 16.4017 3.59835C15.6984 2.89509 14.7446 2.5 13.75 2.5C12.7554 2.5 11.8016 2.89509 11.0983 3.59835C10.3951 4.30161 10 5.25544 10 6.25C10 7.24456 10.3951 8.19839 11.0983 8.90165C11.8016 9.60491 12.7554 10 13.75 10Z" fill="#B284DC"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M6.52 17.5C6.33469 17.1098 6.24228 16.682 6.25 16.25C6.25 14.5563 7.1 12.8125 8.67 11.6C7.88636 11.3586 7.06994 11.2405 6.25 11.25C1.25 11.25 0 15 0 16.25C0 17.5 1.25 17.5 1.25 17.5H6.52Z" fill="#B284DC"/>
<path d="M5.625 10C6.4538 10 7.24866 9.67076 7.83471 9.08471C8.42076 8.49866 8.75 7.7038 8.75 6.875C8.75 6.0462 8.42076 5.25134 7.83471 4.66529C7.24866 4.07924 6.4538 3.75 5.625 3.75C4.7962 3.75 4.00134 4.07924 3.41529 4.66529C2.82924 5.25134 2.5 6.0462 2.5 6.875C2.5 7.7038 2.82924 8.49866 3.41529 9.08471C4.00134 9.67076 4.7962 10 5.625 10Z" fill="#B284DC"/>
</svg>
`,
    product: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12.5694 5.13921H17.9167L13.9583 1.80588C13.8194 1.73644 13.6111 1.66699 13.4722 1.66699H11.25L12.5694 5.13921Z" fill="#FF9800"/>
<path d="M12.7776 6.52832V11.3894H7.22206V6.52832H1.6665V17.6394C1.6665 18.0561 1.94428 18.3339 2.36095 18.3339H17.6387C18.0554 18.3339 18.3332 18.0561 18.3332 17.6394V6.52832H12.7776Z" fill="#FF9800"/>
<path d="M7.43023 5.13921L8.74967 1.66699H6.52745C6.38856 1.66699 6.18023 1.73644 6.11079 1.80588L2.08301 5.13921H7.43023Z" fill="#FF9800"/>
</svg>
`,
    warning: `
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.61085 21.4439C2.94972 21.6401 3.33436 21.7434 3.72593 21.7434H20.2744C21.5036 21.7434 22.5 20.747 22.5 19.5178C22.5 19.1263 22.3967 18.7416 22.2005 18.4027L13.9262 4.11085C13.3104 3.04711 11.9488 2.68403 10.8851 3.29987C10.5486 3.49471 10.269 3.77431 10.0741 4.11085L1.79987 18.4027C1.18403 19.4665 1.54711 20.828 2.61085 21.4439ZM12.9963 8.50591L12.5423 15.0867H11.6345L11.1806 8.50591H12.9963ZM12.0884 18.434C11.4304 18.434 10.8971 17.9007 10.8971 17.2427C10.8971 16.5846 11.4304 16.0513 12.0884 16.0513C12.7465 16.0513 13.2798 16.5846 13.2798 17.2427C13.2798 17.9007 12.7465 18.434 12.0884 18.434Z" fill="#FFAD33"/>
</svg>
`,
    error: `
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.61085 21.4439C2.94972 21.6401 3.33436 21.7434 3.72593 21.7434H20.2744C21.5036 21.7434 22.5 20.747 22.5 19.5178C22.5 19.1263 22.3967 18.7416 22.2005 18.4027L13.9262 4.11085C13.3104 3.04711 11.9488 2.68403 10.8851 3.29987C10.5486 3.49471 10.269 3.77431 10.0741 4.11085L1.79987 18.4027C1.18403 19.4665 1.54711 20.828 2.61085 21.4439ZM12.9963 8.50591L12.5423 15.0867H11.6345L11.1806 8.50591H12.9963ZM12.0884 18.434C11.4304 18.434 10.8971 17.9007 10.8971 17.2427C10.8971 16.5846 11.4304 16.0513 12.0884 16.0513C12.7465 16.0513 13.2798 16.5846 13.2798 17.2427C13.2798 17.9007 12.7465 18.434 12.0884 18.434Z" fill="#FF3B30"/>
</svg>
`,
    success: `
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM6.44445 12.3867L10.3092 16.2514L17.5556 9.00502L16.1063 7.55575L10.3092 13.3528L7.89373 10.9374L6.44445 12.3867Z" fill="#34C759"/>
</svg>
`,
    close: `
<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M13.3333 3.73341L12.2667 2.66675L7.99999 6.93341L3.73332 2.66675L2.66666 3.73341L6.93332 8.00008L2.66666 12.2667L3.73332 13.3334L7.99999 9.06675L12.2667 13.3334L13.3333 12.2667L9.06666 8.00008L13.3333 3.73341Z" fill="#2C1F50"/>
</svg>
`,
};

class AdminIconRegisterService {
    iconRegistry;
    snttitizer;
    constructor(iconRegistry, snttitizer) {
        this.iconRegistry = iconRegistry;
        this.snttitizer = snttitizer;
        this.registerIcon();
    }
    registerIcon() {
        Object.keys(ICONS).forEach((iconName) => {
            this.iconRegistry.addSvgIconLiteral(`admin-${iconName}`, this.snttitizer.bypassSecurityTrustHtml(ICONS[iconName]));
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminIconRegisterService, deps: [{ token: i1$1.MatIconRegistry }, { token: i2$2.DomSanitizer }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminIconRegisterService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminIconRegisterService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.MatIconRegistry }, { type: i2$2.DomSanitizer }] });

// styling
// translate
// formControl
// firefox sida
// .mat-calendar-table-header th {
//   text-align: center;
//   padding: 0 0 8px 0;
class DatePickerComponent {
    adapter;
    adminRegistryIconService;
    ngControl;
    disabled = false;
    width = DEFAULT_INPUT_CONFIG.width;
    height = DEFAULT_INPUT_CONFIG.height;
    value = '';
    minDate = null;
    maxDate = null;
    errorMessage = '';
    onInputChange = new EventEmitter();
    picker;
    onChange = (value) => { };
    onTouched = () => { };
    onValidatorChange = () => { };
    constructor(adapter, adminRegistryIconService, ngControl) {
        this.adapter = adapter;
        this.adminRegistryIconService = adminRegistryIconService;
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    get valid() {
        return !!this.ngControl?.control?.valid;
    }
    get invalid() {
        return !!this.ngControl?.control?.invalid;
    }
    get dirty() {
        return !!this.ngControl?.control?.dirty;
    }
    get touched() {
        return !!this.ngControl?.control?.touched;
    }
    ngOnInit() {
        this.adapter.setLocale('vi');
    }
    isInputInvalid() {
        return (this.invalid && this.touched) || (this.dirty && this.invalid);
    }
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onFocus() { }
    onBlur() {
        this.onTouched();
    }
    onChangeValue(value) {
        this.value = value;
        this.onChange(value);
        this.onTouched();
        this.onValidatorChange();
        this.onInputChange.emit(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: DatePickerComponent, deps: [{ token: i1$2.DateAdapter }, { token: AdminIconRegisterService }, { token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: DatePickerComponent, isStandalone: true, selector: "tpb-date-picker", inputs: { width: "width", height: "height", value: "value", minDate: "minDate", maxDate: "maxDate", errorMessage: "errorMessage" }, outputs: { onInputChange: "onInputChange" }, providers: [
            AdminIconRegisterService,
            {
                provide: MAT_DATE_FORMATS,
                useValue: CUSTOM_DATE_FORMATS,
            },
            {
                provide: DateAdapter,
                useFactory: () => new CustomDateAdapter(),
            },
        ], viewQueries: [{ propertyName: "picker", first: true, predicate: ["picker"], descendants: true, static: true }], ngImport: i0, template: "<admin-form-field \r\n[width]=\"width\" \r\n[height]=\"height\"\r\n[isDisabled]=\"disabled\"\r\n[errorState]=\"isInputInvalid()\"\r\n[errorMessage]=\"errorMessage\"\r\n>\r\n    <input \r\n    [(ngModel)]=\"value\"\r\n    [min]=\"minDate\"\r\n    [max]=\"maxDate\"\r\n    [matDatepicker]=\"picker\"\r\n    (ngModelChange)=\"onChangeValue($event)\"\r\n    type=\"text\" \r\n    adminInput\r\n    placeholder=\"--/--/----\"\r\n    />\r\n    \r\n    <div class=\"dp-picker\" (click)=\"picker.open()\">\r\n\r\n        <mat-icon class=\"dp-picker-icon\"  svgIcon=\"admin-calendar\"></mat-icon>\r\n         <!-- Use the correct icon name -->\r\n\r\n    </div>\r\n         \r\n    <mat-datepicker #picker></mat-datepicker>\r\n</admin-form-field>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.dp-container{display:inline-flex;position:relative;align-items:center;border:.0625rem solid var(--grey-2);border-radius:.25rem;min-width:15.75rem;min-height:2.25rem;box-sizing:border-box;padding:.5rem 1rem}.dp-input{border:none;width:80%;height:1.25rem;color:var(--purple-7)}.dp-input:focus{border:none;-webkit-user-select:none;user-select:none;outline:none}.dp-input::placeholder{color:var(--grey-1)}.dp-picker{position:absolute;top:.5rem;right:1rem}.dp-picker:hover{cursor:pointer}.dp-picker-icon{width:1rem;height:1rem}::ng-deep .mat-calendar-table th,::ng-deep .mat-calendar-table td,::ng-deep .mat-calendar-table .mat-calendar-body-cell-content{color:var(--purple-7)!important}::ng-deep .mat-mdc-button:not(:disabled){background-color:var(--grey-2)!important;background-color:var(--purple-3)!important;color:var(--purple-7)!important}::ng-deep .mat-calendar-body-selected{background-color:var(--purple-3)!important}::ng-deep .mat-calendar-body-selected.mat-calendar-body-today{box-shadow:0 0 0 1px var(--purple-3)!important}::ng-deep .mat-calendar-body-today:not(.mat-calendar-body-selected):not(.mat-calendar-body-comparison-identical){border-color:var(--purple-3)!important}::ng-deep .mat-mdc-icon-button{color:var(--purple-7)!important}::ng-deep .mat-calendar-body-disabled>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected):not(.mat-calendar-body-comparison-identical){color:var(--grey-1)!important}::ng-deep .mat-mdc-icon-button[disabled],.mat-mdc-icon-button.mat-mdc-button-disabled{color:var(--grey-1)!important}\n"], dependencies: [{ kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i4.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i4.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: FormWrapperComponent, selector: "admin-form-field", inputs: ["class", "width", "height", "isDisabled", "errorState", "errorMessage"] }, { kind: "directive", type: InputDirective, selector: "input[type=text][adminInput],[adminInput]", inputs: ["fullWidth", "height", "width"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: DatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tpb-date-picker', standalone: true, imports: [
                        MatDatepickerModule,
                        CommonModule,
                        FormsModule,
                        MatNativeDateModule,
                        MatIconModule,
                        FormWrapperComponent,
                        InputDirective,
                    ], providers: [
                        AdminIconRegisterService,
                        {
                            provide: MAT_DATE_FORMATS,
                            useValue: CUSTOM_DATE_FORMATS,
                        },
                        {
                            provide: DateAdapter,
                            useFactory: () => new CustomDateAdapter(),
                        },
                    ], template: "<admin-form-field \r\n[width]=\"width\" \r\n[height]=\"height\"\r\n[isDisabled]=\"disabled\"\r\n[errorState]=\"isInputInvalid()\"\r\n[errorMessage]=\"errorMessage\"\r\n>\r\n    <input \r\n    [(ngModel)]=\"value\"\r\n    [min]=\"minDate\"\r\n    [max]=\"maxDate\"\r\n    [matDatepicker]=\"picker\"\r\n    (ngModelChange)=\"onChangeValue($event)\"\r\n    type=\"text\" \r\n    adminInput\r\n    placeholder=\"--/--/----\"\r\n    />\r\n    \r\n    <div class=\"dp-picker\" (click)=\"picker.open()\">\r\n\r\n        <mat-icon class=\"dp-picker-icon\"  svgIcon=\"admin-calendar\"></mat-icon>\r\n         <!-- Use the correct icon name -->\r\n\r\n    </div>\r\n         \r\n    <mat-datepicker #picker></mat-datepicker>\r\n</admin-form-field>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.dp-container{display:inline-flex;position:relative;align-items:center;border:.0625rem solid var(--grey-2);border-radius:.25rem;min-width:15.75rem;min-height:2.25rem;box-sizing:border-box;padding:.5rem 1rem}.dp-input{border:none;width:80%;height:1.25rem;color:var(--purple-7)}.dp-input:focus{border:none;-webkit-user-select:none;user-select:none;outline:none}.dp-input::placeholder{color:var(--grey-1)}.dp-picker{position:absolute;top:.5rem;right:1rem}.dp-picker:hover{cursor:pointer}.dp-picker-icon{width:1rem;height:1rem}::ng-deep .mat-calendar-table th,::ng-deep .mat-calendar-table td,::ng-deep .mat-calendar-table .mat-calendar-body-cell-content{color:var(--purple-7)!important}::ng-deep .mat-mdc-button:not(:disabled){background-color:var(--grey-2)!important;background-color:var(--purple-3)!important;color:var(--purple-7)!important}::ng-deep .mat-calendar-body-selected{background-color:var(--purple-3)!important}::ng-deep .mat-calendar-body-selected.mat-calendar-body-today{box-shadow:0 0 0 1px var(--purple-3)!important}::ng-deep .mat-calendar-body-today:not(.mat-calendar-body-selected):not(.mat-calendar-body-comparison-identical){border-color:var(--purple-3)!important}::ng-deep .mat-mdc-icon-button{color:var(--purple-7)!important}::ng-deep .mat-calendar-body-disabled>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected):not(.mat-calendar-body-comparison-identical){color:var(--grey-1)!important}::ng-deep .mat-mdc-icon-button[disabled],.mat-mdc-icon-button.mat-mdc-button-disabled{color:var(--grey-1)!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.DateAdapter }, { type: AdminIconRegisterService }, { type: i1.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { width: [{
                type: Input
            }], height: [{
                type: Input
            }], value: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], onInputChange: [{
                type: Output
            }], picker: [{
                type: ViewChild,
                args: ['picker', { static: true }]
            }] } });

class ButtonComponent {
    label;
    appearance = 'primary';
    class = '';
    disabled = false;
    type = 'button';
    onClick = new EventEmitter();
    handleClick($event) {
        if (this.disabled) {
            $event.preventDefault();
            $event.stopImmediatePropagation();
            return;
        }
        this.onClick.emit();
    }
    customClass() {
        if (this.class) {
            return this.disabled ? `btn-disabled ${this.class}` : this.class;
        }
        else {
            // btn_${this.appearance}-disabled
            return this.disabled
                ? `btn-disabled`
                : `btn-${this.appearance}`;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: ButtonComponent, isStandalone: true, selector: "tpb-button", inputs: { label: "label", appearance: "appearance", class: "class", disabled: "disabled", type: "type" }, outputs: { onClick: "onClick" }, ngImport: i0, template: "<button\r\ntype=\"button\"\r\nclass=\"btn\"\r\n[ngClass]=\"customClass()\"\r\n[disabled]=\"disabled\"\r\n[attr.aria-label]=\"label\"\r\n(click)=\"handleClick($event)\"\r\n>\r\n<ng-content></ng-content>\r\n</button>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.btn{min-width:7.5rem;min-height:2rem;border-radius:.25rem;border:none;padding:.5rem 1rem}.btn:hover{cursor:pointer}.btn:disabled,.btn-disabled{pointer-events:none!important}.btn-primary{background-color:var(--purple-1);color:var(--orange-1)}.btn-primary:active{background-color:var(--purple-5)}.btn-outline-danger{background-color:var(--red-3);color:var(--red-1)}.btn-outline-danger:active{background-color:var(--red-4)}.btn-outline-warning{background-color:var(--orange-2);color:var(--orange-1);border:.0625rem solid var(--orange-1)}.btn-outline-warning:active{background-color:var(--orange-4)}.btn-secondary{background-color:var(--purple-3);color:var(--purple-7)}.btn-secondary:active{background-color:var(--purple-10)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tpb-button', standalone: true, imports: [CommonModule], encapsulation: ViewEncapsulation.Emulated, template: "<button\r\ntype=\"button\"\r\nclass=\"btn\"\r\n[ngClass]=\"customClass()\"\r\n[disabled]=\"disabled\"\r\n[attr.aria-label]=\"label\"\r\n(click)=\"handleClick($event)\"\r\n>\r\n<ng-content></ng-content>\r\n</button>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.btn{min-width:7.5rem;min-height:2rem;border-radius:.25rem;border:none;padding:.5rem 1rem}.btn:hover{cursor:pointer}.btn:disabled,.btn-disabled{pointer-events:none!important}.btn-primary{background-color:var(--purple-1);color:var(--orange-1)}.btn-primary:active{background-color:var(--purple-5)}.btn-outline-danger{background-color:var(--red-3);color:var(--red-1)}.btn-outline-danger:active{background-color:var(--red-4)}.btn-outline-warning{background-color:var(--orange-2);color:var(--orange-1);border:.0625rem solid var(--orange-1)}.btn-outline-warning:active{background-color:var(--orange-4)}.btn-secondary{background-color:var(--purple-3);color:var(--purple-7)}.btn-secondary:active{background-color:var(--purple-10)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], appearance: [{
                type: Input
            }], class: [{
                type: Input
            }], disabled: [{
                type: Input
            }], type: [{
                type: Input
            }], onClick: [{
                type: Output
            }] } });

class AdminCoreWebLibModule {
    static forRoot(environment) {
        return {
            ngModule: AdminCoreWebLibModule,
            providers: [
                AdminIconRegisterService,
                {
                    provide: 'env',
                    useValue: environment
                }
                // Add any services that need to be singleton here
            ],
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibModule, imports: [HttpClientModule,
            ButtonComponent,
            CheckboxComponent,
            DatePickerComponent,
            InputComponent,
            SelectComponent], exports: [ButtonComponent,
            CheckboxComponent,
            DatePickerComponent,
            InputComponent,
            SelectComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibModule, imports: [HttpClientModule,
            ButtonComponent,
            CheckboxComponent,
            DatePickerComponent,
            InputComponent,
            SelectComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCoreWebLibModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        HttpClientModule,
                        ButtonComponent,
                        CheckboxComponent,
                        DatePickerComponent,
                        InputComponent,
                        SelectComponent,
                    ],
                    exports: [
                        ButtonComponent,
                        CheckboxComponent,
                        DatePickerComponent,
                        InputComponent,
                        SelectComponent,
                    ],
                }]
        }] });

class AdminCommunicateService {
    adminEvent = new Subject();
    constructor() { }
    getEvent() {
        return this.adminEvent;
    }
    emmitEvent({ event, data }) {
        this.adminEvent.next({ event, data });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCommunicateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCommunicateService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminCommunicateService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class AdminConfirmModalComponent {
    dialogRef = inject((MatDialogRef));
    dialogData = inject(MAT_DIALOG_DATA);
    modalData = {
        title: '',
        description: '',
        confirmText: '',
        cancelText: '',
    };
    ngOnInit() {
        this.modalData = {
            title: this?.dialogData?.title || '',
            description: this?.dialogData?.description || '',
            confirmText: this?.dialogData?.confirmText || '',
            cancelText: this?.dialogData?.cancelText || 'Đóng',
        };
    }
    handleConfirm() {
        this.dialogRef.close(this.dialogData);
    }
    handleCancel() {
        this.dialogRef.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminConfirmModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: AdminConfirmModalComponent, isStandalone: true, selector: "lib-confirm-modal", ngImport: i0, template: "<div class=\"admin-confirm-modal\">\r\n    <div class=\"admin-confirm-modal-title\">\r\n        {{modalData.title}}\r\n    </div>\r\n    <div class=\"admin-confirm-modal-description\">\r\n        {{modalData.description}}\r\n    </div>\r\n    &nbsp;\r\n    <div class=\"admin-confirm-modal-action\">\r\n       <ng-container *ngIf=\"modalData.confirmText\">\r\n            <tpb-button \r\n                type=\"submit\"  (onClick)=\"handleConfirm()\" appearance=\"primary\">\r\n                {{modalData.confirmText}}\r\n            </tpb-button>\r\n       </ng-container>\r\n\r\n       <ng-container *ngIf=\"modalData.cancelText\">\r\n        <tpb-button \r\n            type=\"submit\"  (onClick)=\"handleCancel()\" appearance=\"primary\">\r\n                {{modalData.cancelText}}\r\n        </tpb-button>\r\n   </ng-container>\r\n    </div>\r\n</div>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}::ng-deep .mat-mdc-dialog-surface{border-radius:5px!important;background-color:var(--white-1)!important;padding:1rem}.admin-confirm-modal{text-align:center}.admin-confirm-modal-title{color:var(--purple-7);font-weight:700;line-height:1.5rem;font-style:normal;margin-bottom:10px}.admin-confirm-modal-description{color:var(--grey-3);font-weight:400;font-size:.875rem;line-height:1.25rem;font-style:normal}.admin-confirm-modal-action{display:flex;justify-content:center;align-items:center}\n"], dependencies: [{ kind: "component", type: ButtonComponent, selector: "tpb-button", inputs: ["label", "appearance", "class", "disabled", "type"], outputs: ["onClick"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminConfirmModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-confirm-modal', standalone: true, imports: [ButtonComponent, CommonModule], template: "<div class=\"admin-confirm-modal\">\r\n    <div class=\"admin-confirm-modal-title\">\r\n        {{modalData.title}}\r\n    </div>\r\n    <div class=\"admin-confirm-modal-description\">\r\n        {{modalData.description}}\r\n    </div>\r\n    &nbsp;\r\n    <div class=\"admin-confirm-modal-action\">\r\n       <ng-container *ngIf=\"modalData.confirmText\">\r\n            <tpb-button \r\n                type=\"submit\"  (onClick)=\"handleConfirm()\" appearance=\"primary\">\r\n                {{modalData.confirmText}}\r\n            </tpb-button>\r\n       </ng-container>\r\n\r\n       <ng-container *ngIf=\"modalData.cancelText\">\r\n        <tpb-button \r\n            type=\"submit\"  (onClick)=\"handleCancel()\" appearance=\"primary\">\r\n                {{modalData.cancelText}}\r\n        </tpb-button>\r\n   </ng-container>\r\n    </div>\r\n</div>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}::ng-deep .mat-mdc-dialog-surface{border-radius:5px!important;background-color:var(--white-1)!important;padding:1rem}.admin-confirm-modal{text-align:center}.admin-confirm-modal-title{color:var(--purple-7);font-weight:700;line-height:1.5rem;font-style:normal;margin-bottom:10px}.admin-confirm-modal-description{color:var(--grey-3);font-weight:400;font-size:.875rem;line-height:1.25rem;font-style:normal}.admin-confirm-modal-action{display:flex;justify-content:center;align-items:center}\n"] }]
        }] });

class AdminModalService {
    matDialog;
    constructor(matDialog) {
        this.matDialog = matDialog;
    }
    open(component, config) {
        return this.matDialog.open(component, config);
    }
    closeAll() {
        this.matDialog.closeAll();
    }
    getDialogById(id) {
        return this.matDialog.getDialogById(id);
    }
    afterAllClosed() {
        return this.matDialog.afterAllClosed;
    }
    afterOpened() {
        return this.matDialog.afterOpened;
    }
    openConfirmModal(config) {
        return this.matDialog.open(AdminConfirmModalComponent, {
            minWidth: 452,
            ...config,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminModalService, deps: [{ token: i1$3.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminModalService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminModalService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$3.MatDialog }] });

class AdminLoadingService {
    _loading = new BehaviorSubject(false);
    get loading() {
        return this._loading;
    }
    show(nextState) {
        return this._loading.next(nextState);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminLoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminLoadingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminLoadingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class AdminSnackbarComponent {
    snackBarRef;
    data = { type: 'info', message: '' };
    constructor(data, snackBarRef) {
        this.snackBarRef = snackBarRef;
        this.data = data;
    }
    parseAdminPrefix() {
        const adminPrefixObbj = {
            success: 'admin-success',
            error: 'admin-error',
            warning: 'admin-warning',
            info: 'admin-info',
        };
        return adminPrefixObbj[this.data.type];
    }
    parseContenttNoti(type) {
        const contentObj = {
            success: {
                class: 'snackbar-title-success',
                title: 'Thành công!',
            },
            error: {
                class: 'snackbar-title-error',
                title: 'Thất bại!',
            },
            warning: {
                class: 'snackbar-title-warning',
                title: 'Cảnh báo!',
            },
            info: {
                class: 'snackbar-title-info',
                title: 'Thông báo!',
            },
        };
        if (type === 'class') {
            return contentObj[this.data.type].class;
        }
        else {
            return contentObj[this.data.type].title;
        }
    }
    closeSnackbar() {
        this.snackBarRef.dismiss();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminSnackbarComponent, deps: [{ token: MAT_SNACK_BAR_DATA }, { token: i1$4.MatSnackBarRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: AdminSnackbarComponent, isStandalone: true, selector: "admin-snackbar", ngImport: i0, template: "<div class=\"admin-snackbar\">\r\n    <div class=\"admin-snackbar-prefix\">\r\n        <mat-icon  [svgIcon]=\"parseAdminPrefix()\"></mat-icon>\r\n    </div>\r\n    <div class=\"admin-snackbar-content\">\r\n        <div [ngClass]=\"parseContenttNoti('class')\">\r\n            {{parseContenttNoti('title')}}\r\n        </div>\r\n\r\n        <div class=\"admin-snackbar-description\">\r\n            {{data.message}}\r\n        </div>\r\n    </div>\r\n    <div class=\"admin-snackbar-suffix\">\r\n        <mat-icon svgIcon=\"admin-close\"  (click)=\"closeSnackbar()\"></mat-icon>\r\n    </div>\r\n</div>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.admin-snackbar{display:inline-flex;width:100%;color:var(--purple-7);align-items:center}.admin-snackbar-prefix{display:flex;justify-content:flex-start;align-items:center;width:36px}.admin-snackbar-content{width:calc(100% - 72px)}.admin-snackbar-suffix{display:flex;justify-content:center;align-items:center;width:36px}.admin-snackbar-suffix:hover{cursor:pointer}.snackbar-title-success{color:var(--green-1)}.snackbar-title-error{color:var(--red-1)}.snackbar-title-warning{color:var(--orange-1)}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminSnackbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'admin-snackbar', standalone: true, imports: [MatIconModule, CommonModule], template: "<div class=\"admin-snackbar\">\r\n    <div class=\"admin-snackbar-prefix\">\r\n        <mat-icon  [svgIcon]=\"parseAdminPrefix()\"></mat-icon>\r\n    </div>\r\n    <div class=\"admin-snackbar-content\">\r\n        <div [ngClass]=\"parseContenttNoti('class')\">\r\n            {{parseContenttNoti('title')}}\r\n        </div>\r\n\r\n        <div class=\"admin-snackbar-description\">\r\n            {{data.message}}\r\n        </div>\r\n    </div>\r\n    <div class=\"admin-snackbar-suffix\">\r\n        <mat-icon svgIcon=\"admin-close\"  (click)=\"closeSnackbar()\"></mat-icon>\r\n    </div>\r\n</div>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.admin-snackbar{display:inline-flex;width:100%;color:var(--purple-7);align-items:center}.admin-snackbar-prefix{display:flex;justify-content:flex-start;align-items:center;width:36px}.admin-snackbar-content{width:calc(100% - 72px)}.admin-snackbar-suffix{display:flex;justify-content:center;align-items:center;width:36px}.admin-snackbar-suffix:hover{cursor:pointer}.snackbar-title-success{color:var(--green-1)}.snackbar-title-error{color:var(--red-1)}.snackbar-title-warning{color:var(--orange-1)}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }, { type: i1$4.MatSnackBarRef }] });

class SnackbarService {
    snackBar;
    constructor(snackBar) {
        this.snackBar = snackBar;
    }
    showError(message, config) {
        return this.createSnackbarFromComponent({
            ...config,
            horizontalPosition: config?.horizontalPosition || 'right',
            verticalPosition: config?.verticalPosition || 'top',
            panelClass: 'snackbar-error',
            data: { type: 'error', message },
        });
    }
    showInfo(message, config) {
        return this.createSnackbarFromComponent({
            ...config,
            data: { type: 'info', message },
            horizontalPosition: config?.horizontalPosition || 'right',
            verticalPosition: config?.verticalPosition || 'top',
            panelClass: 'snackbar-info',
        });
    }
    showWarning(message, config) {
        return this.createSnackbarFromComponent({
            ...config,
            horizontalPosition: config?.horizontalPosition || 'right',
            verticalPosition: config?.verticalPosition || 'top',
            panelClass: 'snackbar-warning',
            data: { type: 'warning', message },
        });
    }
    showSuccess(message, config) {
        return this.createSnackbarFromComponent({
            ...config,
            horizontalPosition: config?.horizontalPosition || 'right',
            verticalPosition: config?.verticalPosition || 'top',
            panelClass: 'snackbar-success',
            data: { type: 'success', message },
        });
    }
    showCustom(config, component) {
        return this.createSnackbarFromComponent(config, component);
    }
    createSnackbarFromComponent(config, component) {
        const Component = component || AdminSnackbarComponent;
        return this.snackBar.openFromComponent(Component, {
            ...config,
            duration: 3000,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: SnackbarService, deps: [{ token: i1$4.MatSnackBar }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: SnackbarService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: SnackbarService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$4.MatSnackBar }] });

class TextAreaComponent {
    ngControl;
    disabled = false;
    noReactiveFormState = {
        touched: false,
    };
    width = '100%';
    height = '116px';
    value = '';
    placeholder = '';
    minLength = DEFAULT_INPUT_CONFIG.minLength;
    maxLength = DEFAULT_INPUT_CONFIG.maxLength;
    required = false;
    onInputChange = new EventEmitter();
    onChange = (value) => { };
    onTouched = () => {
        this.noReactiveFormState.touched = true;
    };
    onValidatorChange = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    get valid() {
        return !!this.ngControl?.control?.valid;
    }
    get invalid() {
        return !!this.ngControl?.control?.invalid;
    }
    get dirty() {
        return !!this.ngControl?.control?.dirty;
    }
    get touched() {
        return this.ngControl
            ? !!this.ngControl?.control?.touched
            : this.noReactiveFormState.touched;
    }
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onFocus() { }
    onBlur() {
        this.onTouched();
    }
    onChangeValue(value) {
        this.value = value;
        this.onChange(value);
        this.onTouched();
        this.onValidatorChange();
        this.onInputChange.emit(value);
    }
    isInputInvalid() {
        return (this.invalid && this.touched) || (this.dirty && this.invalid);
    }
    genCustomClass() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: TextAreaComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: TextAreaComponent, isStandalone: true, selector: "tpb-text-area", inputs: { width: "width", height: "height", value: "value", placeholder: "placeholder", minLength: "minLength", maxLength: "maxLength", required: "required" }, outputs: { onInputChange: "onInputChange" }, ngImport: i0, template: "<admin-form-field class=\"txt-form-field\"\r\nwidth=\"100%\"\r\n[isDisabled]=\"disabled\"\r\n[errorState]=\"isInputInvalid()\"\r\n\r\n>\r\n\r\n<textarea\r\n    class=\"txt-content\"\r\n    adminInput\r\n    [fullWidth]=\"true\"\r\n    [(ngModel)]=\"value\"\r\n    (ngModelChange)=\"onChangeValue($event)\"\r\n    [minLength]=\"minLength\"\r\n    [maxLength]=\"maxLength\"\r\n    [required]=\"required\"\r\n    (focus)=\"onFocus()\"\r\n    (blur)=\"onBlur()\"\r\n    [placeholder]=\"placeholder\"\r\n>\r\n</textarea>\r\n</admin-form-field>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}:host::ng-deep .txt-form-field{min-width:auto!important;padding:0!important}.txt-content{height:auto;padding:.5rem 1rem!important;width:100%!important;min-height:2.25rem!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: FormWrapperComponent, selector: "admin-form-field", inputs: ["class", "width", "height", "isDisabled", "errorState", "errorMessage"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: InputDirective, selector: "input[type=text][adminInput],[adminInput]", inputs: ["fullWidth", "height", "width"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: TextAreaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tpb-text-area', standalone: true, imports: [
                        CommonModule,
                        FormWrapperComponent,
                        ReactiveFormsModule,
                        FormsModule,
                        FormWrapperComponent,
                        InputDirective,
                    ], template: "<admin-form-field class=\"txt-form-field\"\r\nwidth=\"100%\"\r\n[isDisabled]=\"disabled\"\r\n[errorState]=\"isInputInvalid()\"\r\n\r\n>\r\n\r\n<textarea\r\n    class=\"txt-content\"\r\n    adminInput\r\n    [fullWidth]=\"true\"\r\n    [(ngModel)]=\"value\"\r\n    (ngModelChange)=\"onChangeValue($event)\"\r\n    [minLength]=\"minLength\"\r\n    [maxLength]=\"maxLength\"\r\n    [required]=\"required\"\r\n    (focus)=\"onFocus()\"\r\n    (blur)=\"onBlur()\"\r\n    [placeholder]=\"placeholder\"\r\n>\r\n</textarea>\r\n</admin-form-field>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}:host::ng-deep .txt-form-field{min-width:auto!important;padding:0!important}.txt-content{height:auto;padding:.5rem 1rem!important;width:100%!important;min-height:2.25rem!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { width: [{
                type: Input
            }], height: [{
                type: Input
            }], value: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], minLength: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], required: [{
                type: Input
            }], onInputChange: [{
                type: Output
            }] } });

class MenuItemComponent {
    items;
    activeUrl;
    level = 0;
    icon;
    isActive(item) {
        if (item.link && this.activeUrl === item.link) {
            return true;
        }
        if (item.children) {
            return item.children.some((child) => this.isActive(child));
        }
        return false;
    }
    toggleCollapse(item) {
        item.collapsed = !item.collapsed;
    }
    genIcon(item) {
        return `admin-${item.icon}`;
    }
    getIconClass(item) {
        return this.isActive(item) ? 'icon-active' : 'icon-not-active';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: MenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: MenuItemComponent, isStandalone: true, selector: "app-menu-item", inputs: { items: "items", activeUrl: "activeUrl", level: "level" }, providers: [], viewQueries: [{ propertyName: "icon", first: true, predicate: ["icon"], descendants: true, static: true }], ngImport: i0, template: "<ul>\r\n    <ng-container *ngFor=\"let item of items\">\r\n      <li [class.active]=\"isActive(item)\" [class.first-active]=\"level===1 && isActive(item)\">\r\n        \r\n        <a (click)=\"toggleCollapse(item)\" [routerLink]=\"item.link\">\r\n          <ng-container *ngIf=\"level===1\">\r\n            <mat-icon [ngClass]=\"getIconClass(item)\" style=\"width: 16px; height: 16px;\" [svgIcon]=\"genIcon(item)\"></mat-icon>\r\n            &nbsp;\r\n            &nbsp;\r\n          </ng-container>\r\n         <span> {{ item.label }}</span>\r\n\r\n          <span *ngIf=\"item.children && item.children.length>0\" class=\"toggle-icon\" \r\n            [ngClass]=\"item.collapsed ? 'rotate-360' : 'rotate-180'\"\r\n            >\r\n            <mat-icon svgIcon=\"admin-arrow-down\"></mat-icon>\r\n          </span>\r\n        </a>\r\n        <ul *ngIf=\"item.children && !item.collapsed\">\r\n          <app-menu-item [items]=\"item.children\" [activeUrl]=\"activeUrl\"></app-menu-item>\r\n        </ul>\r\n      </li>\r\n    </ng-container>\r\n  </ul>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}ul{box-sizing:border-box;list-style-type:none;padding:0}li:hover{transition:all ease .3s;cursor:pointer}li:hover>a{color:var(--white-1)}a{color:var(--purple-12);box-sizing:border-box;min-height:2.5rem;font-style:normal;font-weight:400;width:100%;padding:.75rem;display:flex;align-items:center;text-decoration:none;-webkit-user-select:none;user-select:none}.material-icons{margin-right:8px}ul ul>li{padding-left:1.5rem}li.first-active>a{background-color:var(--purple-8)}li.first-active>a:hover{transition:all ease .3s;cursor:pointer}li.first-active>a:hover>a{color:var(--white-1);background-color:var(--purple-8)}li.active>a{color:var(--white-1)}.toggle-icon{margin-left:auto}.rotate-0{transform:rotate(0)}.rotate-90{transform:rotate(90deg)}.rotate-180{transform:rotate(180deg)}.rotate-270{transform:rotate(270deg)}.rotate-360{transform:rotate(360deg)}::ng-deep .icon-active svg path{fill:var(--orange-1)}::ng-deep .icon-not-active svg path{fill:var(--purple-4)}\n"], dependencies: [{ kind: "component", type: MenuItemComponent, selector: "app-menu-item", inputs: ["items", "activeUrl", "level"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i1$5.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: MenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-menu-item', standalone: true, imports: [RouterModule, CommonModule, MatIconModule], providers: [], template: "<ul>\r\n    <ng-container *ngFor=\"let item of items\">\r\n      <li [class.active]=\"isActive(item)\" [class.first-active]=\"level===1 && isActive(item)\">\r\n        \r\n        <a (click)=\"toggleCollapse(item)\" [routerLink]=\"item.link\">\r\n          <ng-container *ngIf=\"level===1\">\r\n            <mat-icon [ngClass]=\"getIconClass(item)\" style=\"width: 16px; height: 16px;\" [svgIcon]=\"genIcon(item)\"></mat-icon>\r\n            &nbsp;\r\n            &nbsp;\r\n          </ng-container>\r\n         <span> {{ item.label }}</span>\r\n\r\n          <span *ngIf=\"item.children && item.children.length>0\" class=\"toggle-icon\" \r\n            [ngClass]=\"item.collapsed ? 'rotate-360' : 'rotate-180'\"\r\n            >\r\n            <mat-icon svgIcon=\"admin-arrow-down\"></mat-icon>\r\n          </span>\r\n        </a>\r\n        <ul *ngIf=\"item.children && !item.collapsed\">\r\n          <app-menu-item [items]=\"item.children\" [activeUrl]=\"activeUrl\"></app-menu-item>\r\n        </ul>\r\n      </li>\r\n    </ng-container>\r\n  </ul>", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}ul{box-sizing:border-box;list-style-type:none;padding:0}li:hover{transition:all ease .3s;cursor:pointer}li:hover>a{color:var(--white-1)}a{color:var(--purple-12);box-sizing:border-box;min-height:2.5rem;font-style:normal;font-weight:400;width:100%;padding:.75rem;display:flex;align-items:center;text-decoration:none;-webkit-user-select:none;user-select:none}.material-icons{margin-right:8px}ul ul>li{padding-left:1.5rem}li.first-active>a{background-color:var(--purple-8)}li.first-active>a:hover{transition:all ease .3s;cursor:pointer}li.first-active>a:hover>a{color:var(--white-1);background-color:var(--purple-8)}li.active>a{color:var(--white-1)}.toggle-icon{margin-left:auto}.rotate-0{transform:rotate(0)}.rotate-90{transform:rotate(90deg)}.rotate-180{transform:rotate(180deg)}.rotate-270{transform:rotate(270deg)}.rotate-360{transform:rotate(360deg)}::ng-deep .icon-active svg path{fill:var(--orange-1)}::ng-deep .icon-not-active svg path{fill:var(--purple-4)}\n"] }]
        }], propDecorators: { items: [{
                type: Input
            }], activeUrl: [{
                type: Input
            }], level: [{
                type: Input
            }], icon: [{
                type: ViewChild,
                args: ['icon', { static: true }]
            }] } });

class AdminMenuComponent {
    router;
    searchQuery = '';
    filteredMenuItems = [];
    menuItems = [];
    activeUrl;
    constructor(router) {
        this.router = router;
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd) {
                this.activeUrl = event.urlAfterRedirects;
            }
        });
    }
    ngOnInit() {
        this.activeUrl = this.router.url;
        this.filteredMenuItems = this.menuItems;
    }
    filterMenu() {
        if (!this.searchQuery) {
            this.filteredMenuItems = this.menuItems;
        }
        else {
            this.filteredMenuItems = this.filterItems(this.menuItems, this.searchQuery.toLowerCase());
        }
    }
    filterItems(items, query) {
        return items
            .map((item) => {
            const isMatch = item.label.toLowerCase().includes(query);
            const children = item.children
                ? this.filterItems(item.children, query)
                : [];
            const isChildMatch = children.length > 0;
            return {
                ...item,
                collapsed: !(isMatch || isChildMatch),
                children: children,
            };
        })
            .filter((item) => item.label.toLowerCase().includes(query) ||
            (item.children && item.children.length > 0));
    }
    isActive(item) {
        if (item.link && this.activeUrl === item.link) {
            return true;
        }
        if (item.children) {
            return item.children.some((child) => this.isActive(child));
        }
        return false;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminMenuComponent, deps: [{ token: i1$5.Router }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: AdminMenuComponent, isStandalone: true, selector: "admin-menu", inputs: { menuItems: "menuItems" }, ngImport: i0, template: "<div class=\"menu\">\r\n  <div class=\"menu-header\">\r\n    <div class=\"menu-header__logo\" alt=\"logo\">\r\n      <svg width=\"104\" height=\"24\" viewBox=\"0 0 104 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M25.6542 2.88064C25.6542 2.88064 25.6539 2.88096 25.6536 2.8816C25.6542 2.88064 25.6545 2.88 25.6545 2.88C25.6545 2.88 25.6545 2.88032 25.6542 2.88064ZM25.653 2.88352C25.6533 2.88288 25.6533 2.88256 25.6536 2.88192C25.6536 2.88192 25.6536 2.88192 25.6536 2.8816C25.6536 2.88224 25.6533 2.88256 25.653 2.88352ZM25.6527 2.88384C25.6517 2.88416 25.6517 2.88448 25.6517 2.8848C25.6511 2.88576 25.6505 2.88704 25.6493 2.888C25.6484 2.88992 25.6468 2.89184 25.6462 2.89344C25.5513 3.0496 25.433 3.192 25.2933 3.31424C25.2924 3.31456 25.2921 3.31488 25.2921 3.31552L25.2176 3.37504L25.2146 3.37888L25.1377 3.43968L23.8485 4.45472L19.5827 7.81216L10.4163 15.0266L11.2643 22.2394L11.2901 22.439C11.291 22.4397 11.291 22.4403 11.291 22.4419C11.3222 22.6294 11.3801 22.8074 11.4629 22.9702C11.4641 22.9734 11.4653 22.975 11.4659 22.9773C11.4665 22.9776 11.4671 22.9789 11.4675 22.9802C11.4675 22.9808 11.4684 22.9808 11.4684 22.9808C11.469 22.9821 11.469 22.9827 11.4699 22.9834C11.4699 22.984 11.4699 22.9846 11.4702 22.9853C11.4788 23.0032 11.4886 23.0202 11.4987 23.0374C11.5067 23.0528 11.5156 23.0688 11.5247 23.0845C11.5254 23.0845 11.5254 23.0851 11.526 23.0854C11.5266 23.0864 11.5266 23.0867 11.5275 23.0877C11.5275 23.0883 11.5275 23.0886 11.5275 23.0886C11.5281 23.0899 11.529 23.0915 11.5303 23.0925C11.5315 23.0947 11.533 23.0966 11.5339 23.0989C11.8424 23.6083 12.3868 23.9469 13.0063 23.9469C13.619 23.9469 14.1573 23.616 14.468 23.1162C14.468 23.1155 14.4692 23.1146 14.4692 23.1142C14.4707 23.1117 14.4818 23.0934 14.4851 23.0883C14.4851 23.0877 14.4857 23.0877 14.4857 23.0877C14.4955 23.0707 14.5345 23.0003 14.5439 22.9821L25.4499 3.25152L25.5065 3.14976C25.5065 3.14976 25.6364 2.91424 25.653 2.88352C25.6527 2.88352 25.6527 2.88352 25.6527 2.88384Z\" fill=\"url(#paint0_linear_155_265)\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.0607 0.00032H2.24888H2.13644C2.13644 0.00032 1.82457 0.00032 1.83866 0.00064L1.84142 0.00096H1.84264H1.84417C1.8454 0.00128 1.84754 0.00128 1.84754 0.00128C1.84969 0.00128 1.85398 0.00192 1.85398 0.00192C2.03014 0.0096 2.20783 0.04448 2.37908 0.11072C2.38 0.11072 2.38031 0.11072 2.38092 0.11104L2.46762 0.14848L2.56106 0.18816L4.04754 0.84768L8.96436 3.0272L19.5287 7.71136L25.0852 3.33792L25.2374 3.2144C25.238 3.21408 25.2384 3.21376 25.2393 3.2128C25.379 3.09056 25.4972 2.94848 25.5916 2.79264C25.5928 2.79104 25.5937 2.78944 25.5953 2.78688C25.5959 2.78592 25.5965 2.78528 25.5977 2.78368C25.5977 2.78336 25.5977 2.78336 25.5986 2.78272C25.5986 2.78208 25.5993 2.78144 25.5996 2.78048C25.5996 2.78048 25.6002 2.78016 25.6002 2.7792C25.6103 2.76224 25.6201 2.74528 25.6293 2.728C25.6388 2.71168 25.6464 2.69664 25.655 2.68C25.6553 2.67936 25.6559 2.67904 25.6559 2.6784C25.6559 2.67776 25.6565 2.67712 25.6572 2.67584C25.6572 2.67584 25.6572 2.6752 25.6578 2.67488C25.6584 2.6736 25.659 2.67296 25.659 2.67104C25.6602 2.66912 25.6617 2.6672 25.6627 2.66496C25.931 2.13088 25.9387 1.46944 25.6293 0.9088C25.3232 0.35424 24.7797 0.03264 24.2099 0.00192H24.2078C24.2047 0.00192 24.1845 0.00064 24.1783 0.00032H24.1768C24.1676 0 24.1437 0 24.1195 0C24.0953 0 24.0708 0 24.0607 0.00032Z\" fill=\"url(#paint1_linear_155_265)\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M1.68894 0.00064H1.68679H1.68526H1.68281C1.68281 0.00064 1.68128 0.00064 1.68005 0.00128H1.67331C1.09613 0.0256 0.543754 0.34848 0.233408 0.90912C-0.0729545 1.46368 -0.0680527 2.11616 0.191437 2.64704C0.191743 2.64736 0.191743 2.648 0.192662 2.64864C0.193581 2.65152 0.203078 2.6704 0.205529 2.67648C0.205836 2.6768 0.205836 2.67712 0.205836 2.67712C0.214414 2.6944 0.253935 2.7648 0.26527 2.78272L11.1706 22.5136L11.2269 22.6147C11.2269 22.6147 11.3694 22.872 11.3758 22.8842C11.3758 22.8835 11.3755 22.8829 11.3755 22.8822C11.3752 22.8816 11.3752 22.881 11.3743 22.88C11.3743 22.8797 11.3737 22.8797 11.3737 22.879C11.3728 22.8778 11.3725 22.8765 11.3718 22.8762C11.3712 22.8739 11.3697 22.8714 11.3694 22.8691C11.2873 22.7062 11.2282 22.5283 11.1969 22.3405V22.3379L11.1834 22.241L11.1825 22.2371L11.1706 22.1366L10.9736 20.4627L10.3226 14.9254V14.9251L8.924 3.0272L2.5201 0.18752L2.34149 0.11104C2.34027 0.1104 2.33935 0.1104 2.33935 0.1104C2.16748 0.04416 1.99009 0.00896 1.8124 0.00128H1.80658C1.80658 0.00128 1.80505 0.00064 1.80382 0.00064H1.8026H1.80076H1.79892C1.77993 0 1.76063 0 1.74102 0C1.72417 0 1.70671 0 1.68894 0.00064ZM11.3758 22.8842C11.3761 22.8848 11.3761 22.8848 11.3758 22.8842Z\" fill=\"url(#paint2_linear_155_265)\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M36.0866 6.43171V21.337H32.8763V6.43171H28.9465V3.45059H40.0163V6.43171H36.0866Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M48.1571 6.13329C47.5018 6.13329 46.8474 6.25745 46.4498 6.40657V12.0949C46.7773 12.1691 47.3152 12.2194 47.8532 12.2194C50.1684 12.2194 51.4076 11.076 51.4076 9.18865C51.4076 7.12689 50.2854 6.13329 48.1571 6.13329ZM48.0168 14.8766C47.4556 14.8766 46.8238 14.827 46.4498 14.7525V21.3371H43.2222V4.41969C44.5083 3.82321 46.1924 3.45041 48.1102 3.45041C52.3203 3.45041 54.6355 5.71121 54.6355 9.21329C54.6355 12.4677 52.3904 14.8766 48.0168 14.8766Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M65.2144 13.5239C64.4332 13.0925 63.7675 12.9242 62.2528 12.9242H59.7278V19.2785C60.3705 19.5181 61.4952 19.7105 62.4596 19.7105C65.2144 19.7105 66.752 18.5348 66.752 16.3773C66.752 15.0826 66.2239 14.0996 65.2144 13.5239ZM62.3904 5.08423C61.3573 5.08423 60.3249 5.27623 59.7278 5.51591V11.3901H62.1609C63.7448 11.3901 64.4108 11.2225 65.1452 10.6708C65.8109 10.1674 66.2469 9.20839 66.2469 8.12935C66.2469 6.23559 64.8701 5.08423 62.3904 5.08423ZM62.4596 21.3405C60.8065 21.3405 58.8782 20.9329 57.8455 20.4292V4.36487C58.9474 3.83719 60.6462 3.45383 62.3904 3.45383C66.1782 3.45383 68.1524 5.30023 68.1524 7.98535C68.1524 10.2394 66.6375 11.6538 65.3287 11.9895V12.0375C66.7291 12.3972 68.7262 13.6922 68.7262 16.4733C68.7262 19.4941 66.4533 21.3405 62.4596 21.3405Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M78.1603 14.3152C75.4052 14.4828 72.4218 14.6512 72.4218 17.3363C72.4218 18.847 73.5008 19.8297 75.6582 19.8297C76.5994 19.8297 77.724 19.638 78.1603 19.4224V14.3152ZM75.7039 21.3404C72.3072 21.3404 70.6085 19.8297 70.6085 17.3843C70.6085 13.6924 74.419 13.1404 78.1603 12.9244V11.9417C78.1603 10.0236 76.9437 9.42428 75.2217 9.42428C74.0743 9.42428 72.6516 9.80764 71.848 10.215L71.3428 8.80092C72.2837 8.34524 73.8452 7.88956 75.3828 7.88956C78.1603 7.88956 79.9737 9.04028 79.9737 12.1094V20.4291C79.1018 20.9328 77.334 21.3404 75.7039 21.3404Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M89.4311 21.3405V12.4666C89.4311 10.7107 88.4214 9.58945 86.4245 9.58945C85.3452 9.58945 84.3817 9.80865 83.7843 10.0528V21.3405H81.8563V8.85825C83.0499 8.32161 84.5879 7.93185 86.4015 7.93185C89.6609 7.93185 91.3367 9.54081 91.3367 12.2954V21.3405H89.4311Z\" fill=\"white\"/>\r\n        <mask id=\"mask0_155_265\" style=\"mask-type:luminance\" maskUnits=\"userSpaceOnUse\" x=\"93\" y=\"3\" width=\"11\" height=\"19\">\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M93.2188 3.45407H103.242V21.3405H93.2188V3.45407Z\" fill=\"white\"/>\r\n        </mask>\r\n        <g mask=\"url(#mask0_155_265)\">\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M100.969 21.3405L95.147 14.6989H95.101V21.3405H93.2188V3.45407H95.101V14.3395H95.147L100.947 7.93375H103.242L97.2358 14.5312L103.242 21.3405H100.969Z\" fill=\"white\"/>\r\n        </g>\r\n        <defs>\r\n        <linearGradient id=\"paint0_linear_155_265\" x1=\"14.9699\" y1=\"-5.53439\" x2=\"-2.20048\" y2=\"10.0131\" gradientUnits=\"userSpaceOnUse\">\r\n        <stop stop-color=\"#F3B229\"/>\r\n        <stop offset=\"0.690774\" stop-color=\"#E7792C\"/>\r\n        <stop offset=\"1\" stop-color=\"#CA522D\"/>\r\n        </linearGradient>\r\n        <linearGradient id=\"paint1_linear_155_265\" x1=\"-13.9787\" y1=\"0.496145\" x2=\"-10.2948\" y2=\"15.6083\" gradientUnits=\"userSpaceOnUse\">\r\n        <stop stop-color=\"#F3B229\"/>\r\n        <stop offset=\"0.690774\" stop-color=\"#E7792C\"/>\r\n        <stop offset=\"1\" stop-color=\"#CA522D\"/>\r\n        </linearGradient>\r\n        <linearGradient id=\"paint2_linear_155_265\" x1=\"18.1376\" y1=\"10.3626\" x2=\"-0.799693\" y2=\"1.7605\" gradientUnits=\"userSpaceOnUse\">\r\n        <stop stop-color=\"#F3B229\"/>\r\n        <stop offset=\"0.690774\" stop-color=\"#E7792C\"/>\r\n        <stop offset=\"1\" stop-color=\"#CA522D\"/>\r\n        </linearGradient>\r\n        </defs>\r\n        </svg>\r\n    </div>\r\n\r\n    <div class=\"menu-header__search\">\r\n      <mat-icon class=\"menu-header__search-icon\"  svgIcon=\"admin-search\"></mat-icon>\r\n      &nbsp;\r\n      <input class=\"menu-header__search-input\"  type=\"text\" placeholder=\"T\u00ECm ki\u1EBFm ch\u1EE9c n\u0103ng...\" [(ngModel)]=\"searchQuery\" (input)=\"filterMenu()\">\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"menu-select\">\r\n    <app-menu-item \r\n    [level]=\"1\"\r\n    [items]=\"filteredMenuItems\" [activeUrl]=\"activeUrl\"></app-menu-item>\r\n  </div>\r\n</div>\r\n\r\n\r\n\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.menu{background-color:var(--purple-1);position:fixed;top:0;left:0;width:15rem;height:100vh}.menu-header{padding:.75rem;box-sizing:border-box}.menu-header__logo{width:6.5rem;height:1.5rem;margin-bottom:.75rem}.menu-header__search{width:100%;border:.25rem;background-color:var(--purple-5);display:inline-flex;flex-direction:row;padding:.4375rem .75rem;height:2.25rem;box-sizing:border-box;align-items:center;border-radius:.25rem}.menu-header__search-icon{width:1rem;height:1rem}.menu-header__search-input{background:transparent;border:none;-webkit-user-select:none;user-select:none;outline:none;color:var(--purple-12)}.menu-header__search-input::placeholder{color:var(--purple-12)}.menu-select{height:calc(100vh - 6rem);overflow-y:auto}.menu-select::-webkit-scrollbar{width:.25rem}.menu-select::-webkit-scrollbar-track{background:transparent;border-radius:0 .25rem .25rem 0}.menu-select::-webkit-scrollbar-thumb{background-color:transparent;border-radius:.25rem;border:3px solid var(--purple-12)}.menu-select::-webkit-scrollbar-thumb:hover{background-color:transparent}\n"], dependencies: [{ kind: "component", type: MenuItemComponent, selector: "app-menu-item", inputs: ["items", "activeUrl", "level"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'admin-menu', standalone: true, imports: [MenuItemComponent, FormsModule, MatIconModule, InputDirective], template: "<div class=\"menu\">\r\n  <div class=\"menu-header\">\r\n    <div class=\"menu-header__logo\" alt=\"logo\">\r\n      <svg width=\"104\" height=\"24\" viewBox=\"0 0 104 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M25.6542 2.88064C25.6542 2.88064 25.6539 2.88096 25.6536 2.8816C25.6542 2.88064 25.6545 2.88 25.6545 2.88C25.6545 2.88 25.6545 2.88032 25.6542 2.88064ZM25.653 2.88352C25.6533 2.88288 25.6533 2.88256 25.6536 2.88192C25.6536 2.88192 25.6536 2.88192 25.6536 2.8816C25.6536 2.88224 25.6533 2.88256 25.653 2.88352ZM25.6527 2.88384C25.6517 2.88416 25.6517 2.88448 25.6517 2.8848C25.6511 2.88576 25.6505 2.88704 25.6493 2.888C25.6484 2.88992 25.6468 2.89184 25.6462 2.89344C25.5513 3.0496 25.433 3.192 25.2933 3.31424C25.2924 3.31456 25.2921 3.31488 25.2921 3.31552L25.2176 3.37504L25.2146 3.37888L25.1377 3.43968L23.8485 4.45472L19.5827 7.81216L10.4163 15.0266L11.2643 22.2394L11.2901 22.439C11.291 22.4397 11.291 22.4403 11.291 22.4419C11.3222 22.6294 11.3801 22.8074 11.4629 22.9702C11.4641 22.9734 11.4653 22.975 11.4659 22.9773C11.4665 22.9776 11.4671 22.9789 11.4675 22.9802C11.4675 22.9808 11.4684 22.9808 11.4684 22.9808C11.469 22.9821 11.469 22.9827 11.4699 22.9834C11.4699 22.984 11.4699 22.9846 11.4702 22.9853C11.4788 23.0032 11.4886 23.0202 11.4987 23.0374C11.5067 23.0528 11.5156 23.0688 11.5247 23.0845C11.5254 23.0845 11.5254 23.0851 11.526 23.0854C11.5266 23.0864 11.5266 23.0867 11.5275 23.0877C11.5275 23.0883 11.5275 23.0886 11.5275 23.0886C11.5281 23.0899 11.529 23.0915 11.5303 23.0925C11.5315 23.0947 11.533 23.0966 11.5339 23.0989C11.8424 23.6083 12.3868 23.9469 13.0063 23.9469C13.619 23.9469 14.1573 23.616 14.468 23.1162C14.468 23.1155 14.4692 23.1146 14.4692 23.1142C14.4707 23.1117 14.4818 23.0934 14.4851 23.0883C14.4851 23.0877 14.4857 23.0877 14.4857 23.0877C14.4955 23.0707 14.5345 23.0003 14.5439 22.9821L25.4499 3.25152L25.5065 3.14976C25.5065 3.14976 25.6364 2.91424 25.653 2.88352C25.6527 2.88352 25.6527 2.88352 25.6527 2.88384Z\" fill=\"url(#paint0_linear_155_265)\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.0607 0.00032H2.24888H2.13644C2.13644 0.00032 1.82457 0.00032 1.83866 0.00064L1.84142 0.00096H1.84264H1.84417C1.8454 0.00128 1.84754 0.00128 1.84754 0.00128C1.84969 0.00128 1.85398 0.00192 1.85398 0.00192C2.03014 0.0096 2.20783 0.04448 2.37908 0.11072C2.38 0.11072 2.38031 0.11072 2.38092 0.11104L2.46762 0.14848L2.56106 0.18816L4.04754 0.84768L8.96436 3.0272L19.5287 7.71136L25.0852 3.33792L25.2374 3.2144C25.238 3.21408 25.2384 3.21376 25.2393 3.2128C25.379 3.09056 25.4972 2.94848 25.5916 2.79264C25.5928 2.79104 25.5937 2.78944 25.5953 2.78688C25.5959 2.78592 25.5965 2.78528 25.5977 2.78368C25.5977 2.78336 25.5977 2.78336 25.5986 2.78272C25.5986 2.78208 25.5993 2.78144 25.5996 2.78048C25.5996 2.78048 25.6002 2.78016 25.6002 2.7792C25.6103 2.76224 25.6201 2.74528 25.6293 2.728C25.6388 2.71168 25.6464 2.69664 25.655 2.68C25.6553 2.67936 25.6559 2.67904 25.6559 2.6784C25.6559 2.67776 25.6565 2.67712 25.6572 2.67584C25.6572 2.67584 25.6572 2.6752 25.6578 2.67488C25.6584 2.6736 25.659 2.67296 25.659 2.67104C25.6602 2.66912 25.6617 2.6672 25.6627 2.66496C25.931 2.13088 25.9387 1.46944 25.6293 0.9088C25.3232 0.35424 24.7797 0.03264 24.2099 0.00192H24.2078C24.2047 0.00192 24.1845 0.00064 24.1783 0.00032H24.1768C24.1676 0 24.1437 0 24.1195 0C24.0953 0 24.0708 0 24.0607 0.00032Z\" fill=\"url(#paint1_linear_155_265)\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M1.68894 0.00064H1.68679H1.68526H1.68281C1.68281 0.00064 1.68128 0.00064 1.68005 0.00128H1.67331C1.09613 0.0256 0.543754 0.34848 0.233408 0.90912C-0.0729545 1.46368 -0.0680527 2.11616 0.191437 2.64704C0.191743 2.64736 0.191743 2.648 0.192662 2.64864C0.193581 2.65152 0.203078 2.6704 0.205529 2.67648C0.205836 2.6768 0.205836 2.67712 0.205836 2.67712C0.214414 2.6944 0.253935 2.7648 0.26527 2.78272L11.1706 22.5136L11.2269 22.6147C11.2269 22.6147 11.3694 22.872 11.3758 22.8842C11.3758 22.8835 11.3755 22.8829 11.3755 22.8822C11.3752 22.8816 11.3752 22.881 11.3743 22.88C11.3743 22.8797 11.3737 22.8797 11.3737 22.879C11.3728 22.8778 11.3725 22.8765 11.3718 22.8762C11.3712 22.8739 11.3697 22.8714 11.3694 22.8691C11.2873 22.7062 11.2282 22.5283 11.1969 22.3405V22.3379L11.1834 22.241L11.1825 22.2371L11.1706 22.1366L10.9736 20.4627L10.3226 14.9254V14.9251L8.924 3.0272L2.5201 0.18752L2.34149 0.11104C2.34027 0.1104 2.33935 0.1104 2.33935 0.1104C2.16748 0.04416 1.99009 0.00896 1.8124 0.00128H1.80658C1.80658 0.00128 1.80505 0.00064 1.80382 0.00064H1.8026H1.80076H1.79892C1.77993 0 1.76063 0 1.74102 0C1.72417 0 1.70671 0 1.68894 0.00064ZM11.3758 22.8842C11.3761 22.8848 11.3761 22.8848 11.3758 22.8842Z\" fill=\"url(#paint2_linear_155_265)\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M36.0866 6.43171V21.337H32.8763V6.43171H28.9465V3.45059H40.0163V6.43171H36.0866Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M48.1571 6.13329C47.5018 6.13329 46.8474 6.25745 46.4498 6.40657V12.0949C46.7773 12.1691 47.3152 12.2194 47.8532 12.2194C50.1684 12.2194 51.4076 11.076 51.4076 9.18865C51.4076 7.12689 50.2854 6.13329 48.1571 6.13329ZM48.0168 14.8766C47.4556 14.8766 46.8238 14.827 46.4498 14.7525V21.3371H43.2222V4.41969C44.5083 3.82321 46.1924 3.45041 48.1102 3.45041C52.3203 3.45041 54.6355 5.71121 54.6355 9.21329C54.6355 12.4677 52.3904 14.8766 48.0168 14.8766Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M65.2144 13.5239C64.4332 13.0925 63.7675 12.9242 62.2528 12.9242H59.7278V19.2785C60.3705 19.5181 61.4952 19.7105 62.4596 19.7105C65.2144 19.7105 66.752 18.5348 66.752 16.3773C66.752 15.0826 66.2239 14.0996 65.2144 13.5239ZM62.3904 5.08423C61.3573 5.08423 60.3249 5.27623 59.7278 5.51591V11.3901H62.1609C63.7448 11.3901 64.4108 11.2225 65.1452 10.6708C65.8109 10.1674 66.2469 9.20839 66.2469 8.12935C66.2469 6.23559 64.8701 5.08423 62.3904 5.08423ZM62.4596 21.3405C60.8065 21.3405 58.8782 20.9329 57.8455 20.4292V4.36487C58.9474 3.83719 60.6462 3.45383 62.3904 3.45383C66.1782 3.45383 68.1524 5.30023 68.1524 7.98535C68.1524 10.2394 66.6375 11.6538 65.3287 11.9895V12.0375C66.7291 12.3972 68.7262 13.6922 68.7262 16.4733C68.7262 19.4941 66.4533 21.3405 62.4596 21.3405Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M78.1603 14.3152C75.4052 14.4828 72.4218 14.6512 72.4218 17.3363C72.4218 18.847 73.5008 19.8297 75.6582 19.8297C76.5994 19.8297 77.724 19.638 78.1603 19.4224V14.3152ZM75.7039 21.3404C72.3072 21.3404 70.6085 19.8297 70.6085 17.3843C70.6085 13.6924 74.419 13.1404 78.1603 12.9244V11.9417C78.1603 10.0236 76.9437 9.42428 75.2217 9.42428C74.0743 9.42428 72.6516 9.80764 71.848 10.215L71.3428 8.80092C72.2837 8.34524 73.8452 7.88956 75.3828 7.88956C78.1603 7.88956 79.9737 9.04028 79.9737 12.1094V20.4291C79.1018 20.9328 77.334 21.3404 75.7039 21.3404Z\" fill=\"white\"/>\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M89.4311 21.3405V12.4666C89.4311 10.7107 88.4214 9.58945 86.4245 9.58945C85.3452 9.58945 84.3817 9.80865 83.7843 10.0528V21.3405H81.8563V8.85825C83.0499 8.32161 84.5879 7.93185 86.4015 7.93185C89.6609 7.93185 91.3367 9.54081 91.3367 12.2954V21.3405H89.4311Z\" fill=\"white\"/>\r\n        <mask id=\"mask0_155_265\" style=\"mask-type:luminance\" maskUnits=\"userSpaceOnUse\" x=\"93\" y=\"3\" width=\"11\" height=\"19\">\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M93.2188 3.45407H103.242V21.3405H93.2188V3.45407Z\" fill=\"white\"/>\r\n        </mask>\r\n        <g mask=\"url(#mask0_155_265)\">\r\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M100.969 21.3405L95.147 14.6989H95.101V21.3405H93.2188V3.45407H95.101V14.3395H95.147L100.947 7.93375H103.242L97.2358 14.5312L103.242 21.3405H100.969Z\" fill=\"white\"/>\r\n        </g>\r\n        <defs>\r\n        <linearGradient id=\"paint0_linear_155_265\" x1=\"14.9699\" y1=\"-5.53439\" x2=\"-2.20048\" y2=\"10.0131\" gradientUnits=\"userSpaceOnUse\">\r\n        <stop stop-color=\"#F3B229\"/>\r\n        <stop offset=\"0.690774\" stop-color=\"#E7792C\"/>\r\n        <stop offset=\"1\" stop-color=\"#CA522D\"/>\r\n        </linearGradient>\r\n        <linearGradient id=\"paint1_linear_155_265\" x1=\"-13.9787\" y1=\"0.496145\" x2=\"-10.2948\" y2=\"15.6083\" gradientUnits=\"userSpaceOnUse\">\r\n        <stop stop-color=\"#F3B229\"/>\r\n        <stop offset=\"0.690774\" stop-color=\"#E7792C\"/>\r\n        <stop offset=\"1\" stop-color=\"#CA522D\"/>\r\n        </linearGradient>\r\n        <linearGradient id=\"paint2_linear_155_265\" x1=\"18.1376\" y1=\"10.3626\" x2=\"-0.799693\" y2=\"1.7605\" gradientUnits=\"userSpaceOnUse\">\r\n        <stop stop-color=\"#F3B229\"/>\r\n        <stop offset=\"0.690774\" stop-color=\"#E7792C\"/>\r\n        <stop offset=\"1\" stop-color=\"#CA522D\"/>\r\n        </linearGradient>\r\n        </defs>\r\n        </svg>\r\n    </div>\r\n\r\n    <div class=\"menu-header__search\">\r\n      <mat-icon class=\"menu-header__search-icon\"  svgIcon=\"admin-search\"></mat-icon>\r\n      &nbsp;\r\n      <input class=\"menu-header__search-input\"  type=\"text\" placeholder=\"T\u00ECm ki\u1EBFm ch\u1EE9c n\u0103ng...\" [(ngModel)]=\"searchQuery\" (input)=\"filterMenu()\">\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"menu-select\">\r\n    <app-menu-item \r\n    [level]=\"1\"\r\n    [items]=\"filteredMenuItems\" [activeUrl]=\"activeUrl\"></app-menu-item>\r\n  </div>\r\n</div>\r\n\r\n\r\n\r\n", styles: ["html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:\"\";content:none}table{border-collapse:collapse;border-spacing:0}:root{--black-1: #000000;--white-1: #FFFFFF;--white-2: #F8F8FA;--white-3: #F1F1F2;--purple-1: #7B35BB;--purple-2: #E9DBF5;--purple-3: #DBC6EF;--purple-4: #B284DC;--purple-5: #6E28AF;--purple-6: #DABAD8;--purple-7: #2C1F50;--purple-8: #9758D0;--purple-9: #42236A;--purple-10:#cdb1e7;--purple-11:rgba(0, 0, 0, .05);--purple-12: #AD8AD8;--orange-1: #FF9800;--orange-2: #FFF5E5;--orange-3: #FFD699;--orange-4: #f9e4c4;--red-1: #FF3B30;--red-2: #FFAFAA;--red-3: #FFE9E8;--red-4: #eacac9;--grey-1: #D1D0D9;--grey-2: #DFDEE4;--grey-3: #7A7D9A;--greyr-4: #EFEFF1;--grey-5: #9F9DB0;--green-1: #34C759;--green-2: #17C37B;--green-3:#E8F9EC}html *{font-family:Roboto,Helvetica Neue,sans-serif;line-height:20px;font-size:16px}html{font-size:16px;color:var(--purple-7)}::ng-deep .cdk-overlay-dark-backdrop{background:var(--black-1)!important;transform:scaleX(-1)!important}::ng-deep .cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.7!important}::ng-deep .mdc-snackbar__label{padding:12px 8px 12px 16px}::ng-deep .snackbar-success .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--green-3)!important;position:relative}::ng-deep .snackbar-success .mat-mdc-snackbar-surface:after{position:absolute;background-color:var(--green-1);content:\"\";top:0;left:0;bottom:0;border-radius:4px 0 0 4px;width:.25rem}::ng-deep .snackbar-error .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--red-3)!important}::ng-deep .snackbar-warning .mat-mdc-snackbar-surface{border-radius:.25rem;background:var(--orange-2)!important}.menu{background-color:var(--purple-1);position:fixed;top:0;left:0;width:15rem;height:100vh}.menu-header{padding:.75rem;box-sizing:border-box}.menu-header__logo{width:6.5rem;height:1.5rem;margin-bottom:.75rem}.menu-header__search{width:100%;border:.25rem;background-color:var(--purple-5);display:inline-flex;flex-direction:row;padding:.4375rem .75rem;height:2.25rem;box-sizing:border-box;align-items:center;border-radius:.25rem}.menu-header__search-icon{width:1rem;height:1rem}.menu-header__search-input{background:transparent;border:none;-webkit-user-select:none;user-select:none;outline:none;color:var(--purple-12)}.menu-header__search-input::placeholder{color:var(--purple-12)}.menu-select{height:calc(100vh - 6rem);overflow-y:auto}.menu-select::-webkit-scrollbar{width:.25rem}.menu-select::-webkit-scrollbar-track{background:transparent;border-radius:0 .25rem .25rem 0}.menu-select::-webkit-scrollbar-thumb{background-color:transparent;border-radius:.25rem;border:3px solid var(--purple-12)}.menu-select::-webkit-scrollbar-thumb:hover{background-color:transparent}\n"] }]
        }], ctorParameters: () => [{ type: i1$5.Router }], propDecorators: { menuItems: [{
                type: Input
            }] } });

class AdminMainLayoutComponent {
    menuItems = [
        {
            label: 'Trang chủ',
            icon: 'tpb',
            link: '/home',
        },
        {
            label: 'Quản lý sản phẩm',
            icon: 'product',
            children: [
                {
                    label: 'Danh mục',
                    link: '/products/electronics/mobile-phones',
                },
                {
                    label: 'Sản phẩm',
                    children: [
                        {
                            label: 'Card',
                            link: '/products/clothing/men',
                        },
                    ],
                },
            ],
        },
        {
            label: 'Quản lý phí',
            icon: 'fee',
            link: '/fee',
        },
        {
            label: 'Quản lý lãi',
            icon: 'tpb',
            link: '/tpb',
        },
        {
            label: 'Quản lý phân khúc KH',
            icon: 'customer-group',
            link: '/cutomer-group',
        },
        {
            label: 'Cấu hình kết nối',
            icon: 'connect',
            link: '/connect',
        },
        {
            label: 'Cấu hình khác',
            icon: 'config',
            link: '/config',
        },
        {
            label: 'Phê duyệt tập trung',
            icon: 'mark',
            link: '/approve',
        },
    ];
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminMainLayoutComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: AdminMainLayoutComponent, isStandalone: true, selector: "admin-main-layout", inputs: { menuItems: "menuItems" }, ngImport: i0, template: "<div class=\"layout\">\r\n    <admin-menu [menuItems]=\"menuItems\"></admin-menu>\r\n    <div class=\"content\">\r\n      <!-- Main content goes here -->\r\n        <ng-content></ng-content>\r\n    </div>\r\n  </div>", styles: [".layout{display:flex;height:100vh}.left-menu{width:240px;background-color:#f4f4f4;padding:16px;box-shadow:2px 0 5px #0000001a}.content{width:calc(100% - 240px);margin-left:240px}\n"], dependencies: [{ kind: "component", type: AdminMenuComponent, selector: "admin-menu", inputs: ["menuItems"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminMainLayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'admin-main-layout', standalone: true, imports: [AdminMenuComponent], template: "<div class=\"layout\">\r\n    <admin-menu [menuItems]=\"menuItems\"></admin-menu>\r\n    <div class=\"content\">\r\n      <!-- Main content goes here -->\r\n        <ng-content></ng-content>\r\n    </div>\r\n  </div>", styles: [".layout{display:flex;height:100vh}.left-menu{width:240px;background-color:#f4f4f4;padding:16px;box-shadow:2px 0 5px #0000001a}.content{width:calc(100% - 240px);margin-left:240px}\n"] }]
        }], propDecorators: { menuItems: [{
                type: Input
            }] } });

/**
 * This will carry some information of the app like appversion,etc..
 */
class AdminWrapperComponent {
    adminLoadingService;
    adminIcon;
    isLoading;
    constructor(adminLoadingService, adminIcon) {
        this.adminLoadingService = adminLoadingService;
        this.adminIcon = adminIcon;
    }
    ngOnInit() {
        this.adminLoadingService.loading.subscribe((loading) => {
            this.isLoading = loading;
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminWrapperComponent, deps: [{ token: AdminLoadingService }, { token: AdminIconRegisterService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: AdminWrapperComponent, isStandalone: true, selector: "admin-layout-wrapper", ngImport: i0, template: "<div class=\"admin-layout-wrapper\">\r\n    <ng-content></ng-content>\r\n    <!-- <button (click)=\"load(true)\">turn on</button>\r\n    <button (click)=\"load(false)\">turn off</button> -->\r\n   <ng-container *ngIf=\"isLoading\">\r\n        <div class=\"admin-loading\">\r\n            <img class=\"admin-loading-img\" src=\"assets/admin-loading.gif\" alt=\"loading-spinner\">\r\n        </div>\r\n   </ng-container>\r\n</div>", styles: [".admin-loading{background:#000000b3;position:fixed;width:100vw;height:100vh;z-index:10000;top:0;left:0}.admin-loading-img{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AdminWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'admin-layout-wrapper', standalone: true, imports: [CommonModule], template: "<div class=\"admin-layout-wrapper\">\r\n    <ng-content></ng-content>\r\n    <!-- <button (click)=\"load(true)\">turn on</button>\r\n    <button (click)=\"load(false)\">turn off</button> -->\r\n   <ng-container *ngIf=\"isLoading\">\r\n        <div class=\"admin-loading\">\r\n            <img class=\"admin-loading-img\" src=\"assets/admin-loading.gif\" alt=\"loading-spinner\">\r\n        </div>\r\n   </ng-container>\r\n</div>", styles: [".admin-loading{background:#000000b3;position:fixed;width:100vw;height:100vh;z-index:10000;top:0;left:0}.admin-loading-img{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}\n"] }]
        }], ctorParameters: () => [{ type: AdminLoadingService }, { type: AdminIconRegisterService }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AdminCommunicateService, AdminConfirmModalComponent, AdminCoreWebLibModule, AdminCoreWebLibsComponent, AdminCoreWebLibsService, AdminIconRegisterService, AdminLoadingService, AdminMainLayoutComponent, AdminMenuComponent, AdminModalService, AdminSnackbarComponent, AdminWrapperComponent, ButtonComponent, CheckboxComponent, DatePickerComponent, FormWrapperComponent, InputComponent, MenuItemComponent, SelectComponent, SnackbarService, TextAreaComponent };
//# sourceMappingURL=admin-core-web-libs.mjs.map
