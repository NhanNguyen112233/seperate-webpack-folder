import * as i0 from "@angular/core";
export declare class AdminCoreWebLibsService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminCoreWebLibsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AdminCoreWebLibsService>;
}
