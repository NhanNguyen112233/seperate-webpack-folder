export declare const ICONS: {
    calendar: string;
    'arrow-down': string;
    search: string;
    tpb: string;
    fee: string;
    mark: string;
    config: string;
    connect: string;
    'customer-group': string;
    product: string;
    warning: string;
    error: string;
    success: string;
    close: string;
};
