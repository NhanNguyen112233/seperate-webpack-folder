export declare const DEFAULT_INPUT_CONFIG: {
    width: string;
    height: string;
    innerWidth: string;
    innerHeight: string;
    minLength: number;
    maxLength: number;
};
