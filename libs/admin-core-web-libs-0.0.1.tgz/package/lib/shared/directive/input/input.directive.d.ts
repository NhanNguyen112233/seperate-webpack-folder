import { ElementRef, AfterViewInit, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class InputDirective implements AfterViewInit {
    private el;
    private renderer;
    fullWidth: boolean;
    height: string;
    width: string;
    private readonly COMMON_CONFIG;
    private readonly INPUT_REACT;
    constructor(el: ElementRef, renderer: Renderer2);
    ngAfterViewInit(): void;
    private applyInitialStyles;
    private applyEventListeners;
    private applyPlaceholderStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InputDirective, "input[type=text][adminInput],[adminInput]", never, { "fullWidth": { "alias": "fullWidth"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
