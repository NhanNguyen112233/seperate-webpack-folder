import { EventEmitter } from "@angular/core";
import { ControlValueAccessor, NgControl } from "@angular/forms";
import { MatCheckbox } from "@angular/material/checkbox";
import * as i0 from "@angular/core";
export declare class CheckboxComponent implements ControlValueAccessor {
    private control;
    matCheckbox: MatCheckbox;
    indeterminate: boolean;
    disabled: boolean;
    value: boolean;
    changeEvent: EventEmitter<boolean>;
    constructor(control: NgControl);
    onChangeFn: (_: any) => void;
    onTouchedFn: () => void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(obj: any): void;
    onChange($event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "tpb-checkbox", never, { "indeterminate": { "alias": "indeterminate"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "changeEvent": "changeEvent"; }, never, ["*"], true, never>;
}
