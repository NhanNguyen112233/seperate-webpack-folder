import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { IAdminConfimModal } from './confirm-modal.i';
import * as i0 from "@angular/core";
export declare class AdminConfirmModalComponent implements OnInit {
    readonly dialogRef: MatDialogRef<any, any>;
    readonly dialogData: IAdminConfimModal;
    modalData: IAdminConfimModal;
    ngOnInit(): void;
    handleConfirm(): void;
    handleCancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminConfirmModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminConfirmModalComponent, "lib-confirm-modal", never, {}, {}, never, never, true, never>;
}
