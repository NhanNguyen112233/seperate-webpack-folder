import { EventEmitter } from '@angular/core';
import { IButtonAppearance } from './button.i';
import * as i0 from "@angular/core";
export declare class ButtonComponent {
    label: string;
    appearance: IButtonAppearance;
    class: string;
    disabled: boolean;
    type: 'button' | 'submit' | 'reset';
    onClick: EventEmitter<void>;
    handleClick($event: MouseEvent): void;
    customClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "tpb-button", never, { "label": { "alias": "label"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "class": { "alias": "class"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, { "onClick": "onClick"; }, never, ["*"], true, never>;
}
