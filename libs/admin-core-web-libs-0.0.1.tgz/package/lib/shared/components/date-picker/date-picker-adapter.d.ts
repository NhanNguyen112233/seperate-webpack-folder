import { MatDateFormats, NativeDateAdapter } from '@angular/material/core';
import * as i0 from "@angular/core";
export declare class CustomDateAdapter extends NativeDateAdapter {
    constructor();
    parse(value: any): Date | null;
    format(date: Date, displayFormat: Object): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomDateAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomDateAdapter>;
}
export declare const CUSTOM_DATE_FORMATS: MatDateFormats;
