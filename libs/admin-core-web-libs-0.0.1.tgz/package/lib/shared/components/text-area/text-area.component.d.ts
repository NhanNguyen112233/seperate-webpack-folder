import { EventEmitter } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { IFormWrapperImpl } from '../../template/form-wrapper/form-wrapper.i';
import { IAdminNgControl } from '../../constant/ng-control.i';
import * as i0 from "@angular/core";
export declare class TextAreaComponent implements ControlValueAccessor, IFormWrapperImpl, IAdminNgControl {
    private ngControl;
    disabled: boolean;
    noReactiveFormState: {
        touched: boolean;
    };
    width: string;
    height: string;
    value: string;
    placeholder: string;
    minLength: number;
    maxLength: number;
    required: boolean;
    onInputChange: EventEmitter<string>;
    private onChange;
    private onTouched;
    private onValidatorChange;
    constructor(ngControl: NgControl);
    get valid(): boolean;
    get invalid(): boolean;
    get dirty(): boolean;
    get touched(): boolean;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    onFocus(): void;
    onBlur(): void;
    onChangeValue(value: any): void;
    isInputInvalid(): boolean;
    genCustomClass(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextAreaComponent, "tpb-text-area", never, { "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; "value": { "alias": "value"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "minLength": { "alias": "minLength"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, { "onInputChange": "onInputChange"; }, never, never, true, never>;
}
