import { MatSnackBarRef } from '@angular/material/snack-bar';
import { IAdminSnackbar } from '../../services/admin-snackbar.service';
import * as i0 from "@angular/core";
export declare class AdminSnackbarComponent {
    private snackBarRef;
    data: IAdminSnackbar;
    constructor(data: IAdminSnackbar, snackBarRef: MatSnackBarRef<AdminSnackbarComponent>);
    parseAdminPrefix(): string;
    parseContenttNoti(type: 'class' | 'title'): string;
    closeSnackbar(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminSnackbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminSnackbarComponent, "admin-snackbar", never, {}, {}, never, never, true, never>;
}
