import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class AdminIconRegisterService {
    private iconRegistry;
    private snttitizer;
    constructor(iconRegistry: MatIconRegistry, snttitizer: DomSanitizer);
    private registerIcon;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminIconRegisterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AdminIconRegisterService>;
}
