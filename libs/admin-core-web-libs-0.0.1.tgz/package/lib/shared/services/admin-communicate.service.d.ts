import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export interface AdminEvent {
    event: string;
    data: string;
}
export declare class AdminCommunicateService {
    private adminEvent;
    constructor();
    getEvent(): Observable<AdminEvent>;
    emmitEvent({ event, data }: AdminEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminCommunicateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AdminCommunicateService>;
}
