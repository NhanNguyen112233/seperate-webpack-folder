import { ComponentType } from '@angular/cdk/portal';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { AdminConfirmModalComponent } from '../components/modal/confirm-modal/confirm-modal.component';
import { IAdminConfimModal } from '../components/modal/confirm-modal/confirm-modal.i';
import * as i0 from "@angular/core";
export declare class AdminModalService {
    private matDialog;
    constructor(matDialog: MatDialog);
    open<T, D = any, R = any>(component: ComponentType<T>, config?: MatDialogConfig<D>): MatDialogRef<T, R>;
    closeAll(): void;
    getDialogById(id: string): MatDialogRef<any> | undefined;
    afterAllClosed(): Observable<void>;
    afterOpened(): Observable<MatDialogRef<any>>;
    openConfirmModal<R = any>(config?: MatDialogConfig<IAdminConfimModal>): MatDialogRef<AdminConfirmModalComponent, R>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AdminModalService>;
}
