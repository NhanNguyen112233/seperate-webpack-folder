import { RendererFactory2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AdminElementService {
    private renderer;
    constructor(rendererFactory: RendererFactory2);
    rotate(element: HTMLElement, degrees: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminElementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AdminElementService>;
}
