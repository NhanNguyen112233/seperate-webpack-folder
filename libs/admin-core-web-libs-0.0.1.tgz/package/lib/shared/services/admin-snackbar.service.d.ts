import { MatSnackBar, MatSnackBarConfig, MatSnackBarRef } from '@angular/material/snack-bar';
import { ComponentType } from '@angular/cdk/portal';
import * as i0 from "@angular/core";
export interface IAdminSnackbar {
    type: 'error' | 'info' | 'warning' | 'success';
    message: string;
}
export declare class SnackbarService {
    private snackBar;
    constructor(snackBar: MatSnackBar);
    showError<D>(message: string, config?: MatSnackBarConfig<D>): MatSnackBarRef<unknown>;
    showInfo<D>(message: string, config?: MatSnackBarConfig<D>): MatSnackBarRef<unknown>;
    showWarning<D>(message: string, config?: MatSnackBarConfig<D>): MatSnackBarRef<unknown>;
    showSuccess<D>(message: string, config?: MatSnackBarConfig<D>): MatSnackBarRef<unknown>;
    showCustom<T, D extends IAdminSnackbar = any>(config?: MatSnackBarConfig<D>, component?: ComponentType<T>): MatSnackBarRef<T>;
    private createSnackbarFromComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<SnackbarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SnackbarService>;
}
