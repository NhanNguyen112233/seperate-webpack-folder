import { BehaviorSubject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class AdminLoadingService {
    private _loading;
    get loading(): BehaviorSubject<boolean>;
    show(nextState: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminLoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AdminLoadingService>;
}
