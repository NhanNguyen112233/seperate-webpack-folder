import { OnInit } from '@angular/core';
import { MenuItem } from './menu-item/menu-item.component';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare class AdminMenuComponent implements OnInit {
    private router;
    searchQuery: string;
    filteredMenuItems: MenuItem[];
    menuItems: MenuItem[];
    activeUrl: string;
    constructor(router: Router);
    ngOnInit(): void;
    filterMenu(): void;
    filterItems(items: MenuItem[], query: string): MenuItem[];
    isActive(item: MenuItem): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminMenuComponent, "admin-menu", never, { "menuItems": { "alias": "menuItems"; "required": false; }; }, {}, never, never, true, never>;
}
