import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export interface MenuItem {
    label: string;
    icon?: string;
    link?: string;
    children?: MenuItem[];
    collapsed?: boolean;
}
export declare class MenuItemComponent {
    items: MenuItem[];
    activeUrl: string;
    level: number;
    icon: ElementRef;
    isActive(item: MenuItem): boolean;
    toggleCollapse(item: MenuItem): void;
    genIcon(item: MenuItem): string;
    getIconClass(item: MenuItem): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MenuItemComponent, "app-menu-item", never, { "items": { "alias": "items"; "required": false; }; "activeUrl": { "alias": "activeUrl"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, true, never>;
}
