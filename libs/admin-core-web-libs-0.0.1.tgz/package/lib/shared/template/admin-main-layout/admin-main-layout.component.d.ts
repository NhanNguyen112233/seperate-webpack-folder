import { MenuItem } from '../menu/menu-item/menu-item.component';
import * as i0 from "@angular/core";
export declare class AdminMainLayoutComponent {
    menuItems: MenuItem[];
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminMainLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminMainLayoutComponent, "admin-main-layout", never, { "menuItems": { "alias": "menuItems"; "required": false; }; }, {}, never, ["*"], true, never>;
}
