import { AdminLoadingService } from './../../services/admin-loading.service';
import { OnInit } from '@angular/core';
import { AdminIconRegisterService } from '../../services/admin-icon-register.service';
import * as i0 from "@angular/core";
/**
 * This will carry some information of the app like appversion,etc..
 */
export declare class AdminWrapperComponent implements OnInit {
    private adminLoadingService;
    private adminIcon;
    isLoading: boolean;
    constructor(adminLoadingService: AdminLoadingService, adminIcon: AdminIconRegisterService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminWrapperComponent, "admin-layout-wrapper", never, {}, {}, never, ["*"], true, never>;
}
