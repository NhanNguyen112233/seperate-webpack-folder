import { FormGroupDirective } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormWrapperComponent {
    private formGroupDirective;
    class: string;
    width: string;
    height: string;
    isDisabled: boolean;
    errorState: boolean;
    errorMessage: string;
    constructor(formGroupDirective: FormGroupDirective);
    customClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormWrapperComponent, "admin-form-field", never, { "class": { "alias": "class"; "required": false; }; "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "errorState": { "alias": "errorState"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; }, {}, never, ["*"], true, never>;
}
