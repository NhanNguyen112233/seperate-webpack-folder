import * as i0 from "@angular/core";
export declare class AdminCoreWebLibsComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminCoreWebLibsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminCoreWebLibsComponent, "lib-admin-core-web-libs", never, {}, {}, never, never, true, never>;
}
