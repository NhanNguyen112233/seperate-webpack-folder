import { ModuleWithProviders } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
import * as i2 from "./shared/components/button/button.component";
import * as i3 from "./shared/components/checkbox/checkbox.component";
import * as i4 from "./shared/components/date-picker/date-picker.component";
import * as i5 from "./shared/components/input/input.component";
import * as i6 from "./shared/components/select/select.component";
export declare class AdminCoreWebLibModule {
    static forRoot(environment: any): ModuleWithProviders<AdminCoreWebLibModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminCoreWebLibModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AdminCoreWebLibModule, never, [typeof i1.HttpClientModule, typeof i2.ButtonComponent, typeof i3.CheckboxComponent, typeof i4.DatePickerComponent, typeof i5.InputComponent, typeof i6.SelectComponent], [typeof i2.ButtonComponent, typeof i3.CheckboxComponent, typeof i4.DatePickerComponent, typeof i5.InputComponent, typeof i6.SelectComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AdminCoreWebLibModule>;
}
