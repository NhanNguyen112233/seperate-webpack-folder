/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="admin-core-web-libs" />
export * from './public-api';
